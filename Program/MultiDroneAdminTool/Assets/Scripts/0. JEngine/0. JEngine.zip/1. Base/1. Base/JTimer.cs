using System;
using System.Collections.Generic;
using System.Threading;


namespace J2y
{
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //
    // JTimer
    //
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    public class JTimer
    {

        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // ���� �Լ�
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [���� Tick]
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static long GetCurrentTick()
        {
            return DateTime.Now.Ticks;
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static DateTime GetCurrentTime()
        {
            return DateTime.Now;
        }
        #endregion

        #region [�ð� ��ȯ]
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static float TickToTime(long tick)
        {
            return (float)TimeSpan.FromTicks(tick).TotalSeconds;
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static long TimeToTick(float time)
        {
            return TimeSpan.FromSeconds(time).Ticks;
        }
        #endregion



        #region [���� �ð�]
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static long GetElaspedTick(long start_tick)
        {
            return GetCurrentTick() - start_tick;
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static float GetElaspedTime(long start_tick)
        {
            return TickToTime(GetCurrentTick() - start_tick);
        }
        #endregion

        #region [���� �ð�]
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static float GetRemainTime(long start_tick, long duration)
        {
            return Math.Max(0, duration - GetElaspedTime(start_tick));
        }
        #endregion


        #region [���� �˻�]
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static bool CheckRange(long start_tick, long end_tick, long cur_tick)
        {
            return ((cur_tick >= start_tick) && (cur_tick <= end_tick));
        }
        #endregion

        #region [��/��/�� �˻�]
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static bool IsSameDay(long tick1, long tick2)
        {
            var dt1 = new DateTime(tick1);
            var dt2 = new DateTime(tick2);
            return (dt1.DayOfYear == dt2.DayOfYear);
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static bool IsSameWeek(long tick1, long tick2)
        {
            var dt1 = new DateTime(tick1);
            var dt2 = new DateTime(tick2);
            return (dt1.DayOfWeek == dt2.DayOfWeek);
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static bool IsSameMonth(long tick1, long tick2)
        {
            var dt1 = new DateTime(tick1);
            var dt2 = new DateTime(tick2);
            return (dt1.Month == dt2.Month);
        }

        public static long AddDay(long tick1, int day)
        {
            var dt1 = new DateTime(tick1);
            dt1 = dt1.AddDays(day);
            return dt1.Ticks;
        }
        #endregion


        #region [Sleep] Idle Time
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void SleepIdleTime(DateTime start_time, int max_sleep_time = 5)
        {
            var elapsedTime = (JTimer.GetCurrentTime() - start_time);
            var sleepTIme = Math.Min(max_sleep_time - elapsedTime.Milliseconds, max_sleep_time);
            if (sleepTIme > 0)
                System.Threading.Thread.Sleep(sleepTIme);
        }
        #endregion




        #region ���ڿ� ��ȯ
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static string ToString(long tick)
        {
            var span = new TimeSpan(tick);
            return String.Format("{0}:{1}:{2}", span.Hours, span.Minutes, span.Seconds);
        }
        #endregion

    }

}
