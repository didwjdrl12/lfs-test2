using UnityEngine;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Text;


namespace J2y
{
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //
    // JCsvParser
    //
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    public class JCsvParser
    {
        public static string s_data_path = "DataInfo/";
        
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // ���� �Ľ�
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [�����Ľ�]
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static IDictionary<long, T> Load<T>(string fileName) where T : JDataInfo_base, new()
        {
            var fileFullPath = s_data_path + fileName;
            //var txtFile = VcResourceManager.Instance.LoadAsset<TextAsset>("db.unity3d", fileName, s_data_path);
            var full_text = "";
#if PROTO_SERVER
            fileFullPath += ".txt";
            full_text = File.ReadAllText(fileFullPath);
#else
            var txtFile = Resources.Load(fileFullPath, typeof(TextAsset)) as TextAsset;
			full_text = txtFile.text;
#endif

            var reader = new StringReader(full_text);
            if (reader == null)
            {
                JLogger.WriteError("File not found or not readable : " + fileFullPath);
                return null;
            }

            int lineCount = 0;
            var inputData = reader.ReadLine();
            var res_datas = new Dictionary<long, T>();

            while (inputData != null)
            {

                //-------------------------------------------------------------------
                // 1. ��ū �и� �� �ش� Ȯ��

                var stringList = inputData.Split('\t');
                if (stringList.Length == 0)
                    continue;
                if (lineCount == 0)
                {
                    var header = inputData;
                    lineCount++;
                    inputData = reader.ReadLine();
                    continue;
                }
                for (int i = 0; i < stringList.Length; i++)
                    stringList[i] = stringList[i].Replace("\\n", "\n");     // \n���ڸ� \\n���� �ִ� TextAsset�� ���� ����..


                //-------------------------------------------------------------------
                // 2. ������ ���� �Ľ�

                var data_line = new T();
                if (data_line.VarifyKey(stringList[0]) == false)
                {
                    JLogger.Write("VarifyKey fail : " + inputData[0]);
                    continue;
                }
                data_line.Parse(stringList);
                res_datas.Add(data_line._guid, data_line);
                inputData = reader.ReadLine();
                lineCount++;
            }

            JLogger.WriteFormat("[DataTable] [{0} Count]{1}", lineCount, fileName);

            reader.Dispose();
            reader.Close();

            return res_datas;
        }
        #endregion



        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // ���
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [���]
        //protected static string LoadFileToString(string fileName)
        //{
        //    string fileFullPath = "Vendetta/DataTable/" + fileName;
        //    TextAsset _txtFile = Resources.Load(fileFullPath, typeof(TextAsset)) as TextAsset;
        //    TextReader reader = new StringReader(_txtFile.text);
        //    string _info = reader.ReadToEnd();
        //    reader.Close();

        //    byte[] buffers = StringToUTF8ByteArray(_info);

        //    return _info;
        //}

        //private static byte[] StringToUTF8ByteArray(string _string)
        //{
        //    UTF8Encoding encoding = new UTF8Encoding();
        //    byte[] byteArray = encoding.GetBytes(_string);
        //    return byteArray;
        //} 
        #endregion
    }
}
