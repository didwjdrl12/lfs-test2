using UnityEngine;
using System.Collections.Generic;
using System;
using System.IO;


namespace J2y
{
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //
    // JDataInfo
    //
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    [Serializable]
    public abstract class JDataInfo_base
    {
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // ����
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [����] Base

        public long _guid;
        #endregion


        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // [Property]
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [Property] 

        #endregion


        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // [���̽�]
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


        #region [���̽�] Clone
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public virtual object Clone()
        {
            var dataBase = (JDataInfo_base)this.MemberwiseClone();
            dataBase._guid = _guid;
            return dataBase;
        }

        #endregion


        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // [CSV �Ľ�]
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [CSV �Ľ�]
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public virtual bool VarifyKey(string KeyValue) { return true; }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public virtual void Parse(string[] inputData)
        {
            _guid = Convert.ToInt64(inputData[0]);
        }
        #endregion

        #region [CSV �Ľ�] [��ƿ]

        #region string -> enum
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static T ParseEnum<T>(string str_enum)
        {
            if (!Enum.IsDefined(typeof(T), str_enum))
                return default(T);
            return (T)Enum.Parse(typeof(T), str_enum);
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static T[] ParseEnumArray<T>(string str_enum_array, char separator = ',')
        {
            var strs = str_enum_array.Split(',');
            if (strs.Length == 0)
                return null;
            var result = new T[strs.Length];
            for (int i = 0; i < result.Length; ++i)
            {
                var str_enum = strs[i];
                if (!Enum.IsDefined(typeof(T), str_enum))
                    result[i] = default(T);
                result[i] = (T)Enum.Parse(typeof(T), str_enum);
            }
            return result;
        }
        #endregion

        #region string -> Vector3
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static Vector3 ParseVector3(string str_in)
        {
            var v = Vector3.zero;
            var strs = str_in.Split(',');
            if (strs.Length < 3)
                return v;

            v.x = Convert.ToSingle(strs[0]);
            v.y = Convert.ToSingle(strs[1]);
            v.z = Convert.ToSingle(strs[2]);
            return v;
        }
        #endregion

        #region List
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static int[] ParseIntArray(string str_line, char separator = '#')
        {
            var strs = str_line.Split(separator);
            var result = new int[strs.Length];
            for (int i = 0; i < result.Length; ++i)
                int.TryParse(strs[i], out result[i]);
            return result;
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static long[] ParseLongArray(string str_line, char separator = '#')
        {
            var strs = str_line.Split(separator);
            var result = new long[strs.Length];
            for (int i = 0; i < result.Length; ++i)
                long.TryParse(strs[i], out result[i]);
            return result;
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static float[] ParseFloatArray(string str_line, char separator = '#')
        {
            var strs = str_line.Split(separator);
            var result = new float[strs.Length];
            for (int i = 0; i < result.Length; ++i)
                float.TryParse(strs[i], out result[i]);
            return result;
        }
        #endregion

        #region Dictionary
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static Dictionary<T0, T1> ParseDictionary<T0, T1>(string str_line, char sep1 = '#', char sep2 = ',')
            where T0 : IConvertible
            where T1 : IConvertible
        {
            var groups = str_line.Split(sep1);
            var result = new Dictionary<T0, T1>();

            for (int i = 0; i < groups.Length; ++i)
            {
                var strs = groups[i].Split(sep2);

                if (strs.Length == 2)
                {
                    //double v0, v1;
                    //double.TryParse(strs[0], out v0);
                    //double.TryParse(strs[1], out v1);
                    var v0 = (T0)Convert.ChangeType(strs[0], typeof(T0));
                    var v1 = (T1)Convert.ChangeType(strs[1], typeof(T1));
                    result[v0] = v1;
                }
            }
            return result;
        }
        #endregion


        #endregion

        #region [CSV �Ľ�] [�̺�Ʈ] OnLoad
        public virtual void OnLoad()
        {
        }
        #endregion

    }



}
