using System.IO;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using UnityEngine;
using System.Reflection;
using System.Collections;
using System;

namespace J2y.Network
{
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //
    // SerializationSurrogate
    //
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region [SerializationSurrogate] Vector3
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    sealed class Vector3SerializationSurrogate : ISerializationSurrogate
    {
        #region [Serialize] GetObjectData
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public void GetObjectData(System.Object obj, SerializationInfo info, StreamingContext context)
        {         
            var v3 = (Vector3) obj;
            info.AddValue("x", v3.x);
            info.AddValue("y", v3.y);
            info.AddValue("z", v3.z);
            //Debug.Log(v3);
        }
        #endregion

        #region [Deserialize] SetObjectData
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public System.Object SetObjectData(System.Object obj, SerializationInfo info, StreamingContext context, ISurrogateSelector selector)
        {         
            var v3 = (Vector3) obj;
            v3.x = (float)info.GetValue("x", typeof(float));
            v3.y = (float)info.GetValue("y", typeof(float));
            v3.z = (float)info.GetValue("z", typeof(float));
            obj = v3;
            return obj;   // Formatters ignore this return value //Seems to have been fixed!
        }
        #endregion

    }
    #endregion

    #region [SerializationSurrogate] Quaternion
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    sealed class QuaternionSerializationSurrogate : ISerializationSurrogate
    {
        #region [Serialize] GetObjectData
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public void GetObjectData(System.Object obj, SerializationInfo info, StreamingContext context)
        {
            var q = (Quaternion)obj;
            info.AddValue("x", q.x);
            info.AddValue("y", q.y);
            info.AddValue("z", q.z);
            info.AddValue("w", q.w);
            //Debug.Log(v3);
        }
        #endregion

        #region [Deserialize] SetObjectData
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public System.Object SetObjectData(System.Object obj, SerializationInfo info, StreamingContext context, ISurrogateSelector selector)
        {
            var q = (Quaternion)obj;
            q.x = (float)info.GetValue("x", typeof(float));
            q.y = (float)info.GetValue("y", typeof(float));
            q.z = (float)info.GetValue("z", typeof(float));
            q.w = (float)info.GetValue("w", typeof(float));
            obj = q;
            return obj;   // Formatters ignore this return value //Seems to have been fixed!
        }
        #endregion

    }
    #endregion



    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //
    // JSerialization
    //
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    public static class JSerialization
    {

        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        //  [BinaryFormatter]
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        private static BinaryFormatter s_binary_formatter;

        #region [BinaryFormatter] ���� (+ SerializationSurrogate)
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static BinaryFormatter MakeBinaryFormatter()
        {
            var bf = new BinaryFormatter();

            var ss = new SurrogateSelector();
            ss.AddSurrogate(typeof(Vector3), new StreamingContext(StreamingContextStates.All), new Vector3SerializationSurrogate());
            ss.AddSurrogate(typeof(Quaternion), new StreamingContext(StreamingContextStates.All), new QuaternionSerializationSurrogate());


            bf.SurrogateSelector = ss;
            return bf;
        }
        #endregion

        #region [BinaryFormatter] GET
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static BinaryFormatter GetBinaryFormatter()
        {
            if (null == s_binary_formatter)
                s_binary_formatter = MakeBinaryFormatter();

            return s_binary_formatter;
        }
        #endregion


        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        //  [Serialization]
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [Serialize] Stream/BinaryWriter
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void Serialize(Stream serializationStream, object graph)
        {
            GetBinaryFormatter().Serialize(serializationStream, graph);
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void Serialize(BinaryWriter writer, object graph)
        {
            GetBinaryFormatter().Serialize(writer.BaseStream, graph);
        }
        #endregion


        #region [Deserialize] Stream/BinaryReader
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static object Deserialize(Stream serializationStream)
        {
            return GetBinaryFormatter().Deserialize(serializationStream);
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static object Deserialize(BinaryReader reader)
        {
            return GetBinaryFormatter().Deserialize(reader.BaseStream);
        }
        #endregion

        #region [Deserialize] NetData
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static T Deserialize<T>(Stream serializationStream) where T : class
        {
            var obj = Deserialize(serializationStream);
            return obj as T;
        }
        #endregion

    }


    public static class JNewSerialization
    {
        #region [Serialize] object (List, Dictionary, PrimitiveType, NetData)
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void Serialize(BinaryWriter writer, object value)
        {
            Type t = value.GetType();
            MethodInfo writeMethod;

            if (JReflection.s_write_methods.TryGetValue(t, out writeMethod))
            {
                writeMethod.Invoke(writer, new object[] { value });
                return;
            }

            if (typeof(IList).IsAssignableFrom(t))
            {
                var list = value as IList;

                int count = list.Count;
                Serialize(writer, count);

                for (int i = 0; i < count; ++i)
                    Serialize(writer, list[i]);

                return;
            }

            if (typeof(IDictionary).IsAssignableFrom(t))
            {
                var dict = value as IDictionary;

                int count = dict.Count;
                Serialize(writer, count);

                foreach (var key in dict.Keys)
                {
                    Serialize(writer, key);
                    Serialize(writer, dict[key]);
                }

                return;
            }

            var fields = t.GetFields();

            foreach (var fi in fields)
            {
                var target = fi.GetValue(value);
                if (target == null)
                    throw new Exception("JNewSerialization::Serialize - target is null");
                //target = Activator.CreateInstance(fi.GetType()); // unity bug

                Serialize(writer, target);
            }
        }


        #endregion

        #region [Serialize] NetData
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void Serialize<T>(BinaryWriter writer, object value)
        {
            var tp = typeof(T);
            var fields = tp.GetFields();

            foreach (var fi in fields)
            {
                var target = fi.GetValue(value);
                if (target == null)
                    throw new Exception("JNewSerialization::Serialize<T> - target is null");
                //target = Activator.CreateInstance(fi.GetType()); // unity bug

                Serialize(writer, target);
            }
        }
        #endregion

        #region [Serialize] RPC (object[])
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void Serialize(BinaryWriter writer, params object[] args)
        {
            for (int i = 0; i < args.Length; ++i)
            {
                if (args[i] == null)
                    throw new Exception("JNewSerialization::Serialize - args[] is null");

                Serialize(writer, args[i]);
            }
        }

        #endregion



        #region [Deserialize] object (List, Dictionary, PrimitiveType, NetData)
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static object Deserialize(BinaryReader reader, Type t)
        {
            // native deserialize
            MethodInfo readMethod;
            if (JReflection.s_read_methods.TryGetValue(t, out readMethod))
            {
                return readMethod.Invoke(reader, null);
            }

            var target = Activator.CreateInstance(t); // create instance

            // list deserialize
            if (typeof(IList).IsAssignableFrom(t))
            {
                var list = target as IList;
                var list_itemType = t.GetGenericArguments()[0];

                int count = (int)Deserialize(reader, typeof(int));
                for (int i = 0; i < count; ++i)
                {
                    list.Add(Deserialize(reader, list_itemType));
                }

                return list;
            }

            // dict deserialize
            if (typeof(IDictionary).IsAssignableFrom(t))
            {
                var dict = target as IDictionary;

                var dict_keyType = t.GetGenericArguments()[0];
                var dict_itemType = t.GetGenericArguments()[1];

                int count = (int)Deserialize(reader, typeof(int));
                for (int i = 0; i < count; ++i)
                {
                    dict.Add(Deserialize(reader, dict_keyType), Deserialize(reader, dict_itemType));
                }

                return dict;
            }

            // class deserialize
            var fields = t.GetFields();

            foreach (var fi in fields)
            {
                fi.SetValue(target, Deserialize(reader, fi.FieldType));
            }

            return target;
        }
        #endregion

        #region [Deserialize] NetData
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static T Deserialize<T>(BinaryReader reader)
        {
            var tp = typeof(T);
            var fields = tp.GetFields();
            var target = Activator.CreateInstance(tp);

            foreach (var fi in fields)
            {
                fi.SetValue(target, Deserialize(reader, fi.FieldType));
            }

            return (T)target;
        }
        #endregion

        #region [Deserialize] RPC (object[])
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static object[] Deserialize(BinaryReader reader, MethodInfo mi)
        {
            var arguments = mi.GetGenericArguments();
            var targets = new object[arguments.Length];

            for (int i = 0; i < arguments.Length; ++i)
            {
                targets[i] = Deserialize(reader, arguments[i]);
            }

            return targets;
        }

        #endregion
    }
}
