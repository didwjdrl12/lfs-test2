using UnityEngine;
using System;
using System.Collections.Generic;
using J2y.Network;
using System.Threading;
using System.Threading.Tasks;

namespace J2y
{
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //
    // JScheduledEvent
    //		Used by the JScheduler, the JScheduledEvent contains the delegate and arguments for the event that should execute at a time in the future.
    //
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


    public class JScheduledEvent
    {
        #region [����] Internal
        private Action m_Callback = null;
        private Action<object> m_CallbackArg = null;
        private object m_Argument;
        private long m_EndTime;
        #endregion

        #region [Property] 
        public Action Callback { get { return m_Callback; } set { m_Callback = value; } }
        public Action<object> CallbackArg { get { return m_CallbackArg; } set { m_CallbackArg = value; } }
        public object Argument { get { return m_Argument; } set { m_Argument = value; } }
        public long EndTime { get { return m_EndTime; } set { m_EndTime = value; } }
        #endregion

        #region [Reset]
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public void Reset()
        {
            m_Callback = null;
            m_CallbackArg = null;
            m_Argument = null;
        }
        #endregion

    }

	public class JScheduledEventExtend : JScheduledEvent
	{
		#region [����] Internal
		private long m_BeginTime;
		private long m_Length;
		private long m_ParseTime;
        private long m_RunningTime;
        private bool is_puase;
        #endregion

        #region [Property]
        public long BeginTime { get { return m_BeginTime; } set { m_BeginTime = value; } }
		public long Length { get { return m_Length; } set { m_Length = value; } }
		public long ParseTime { get { return m_ParseTime; } set { m_ParseTime = value; } }
        public long RunningTime { get { return is_puase ? m_RunningTime : m_RunningTime + (JTimer.GetCurrentTick() - m_BeginTime); } }
        public long RemainingTime { get { return Length - RunningTime; } }
        #endregion

        #region [Start]
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public void Start()
		{
            is_puase = false;
            m_ParseTime = m_BeginTime = JTimer.GetCurrentTick();
            if (m_Length == 0)
                m_Length = EndTime - m_BeginTime;
            else
                EndTime = m_BeginTime + m_Length;
            m_RunningTime = 0;
        }
		#endregion

		#region [Pause]
		//------------------------------------------------------------------------------------------------------------------------------------------------------
		public void Pause()
		{
            if (is_puase)
                return;

            is_puase = true;
            m_ParseTime = JTimer.GetCurrentTick();
            m_RunningTime += m_ParseTime - m_BeginTime;
        }
		#endregion

		#region [Continue]
		//------------------------------------------------------------------------------------------------------------------------------------------------------
		public void Continue()
		{
            if (!is_puase)
                return;

            is_puase = false;
            m_ParseTime = m_BeginTime = JTimer.GetCurrentTick();
			EndTime = m_BeginTime + (m_Length - m_RunningTime);
		}
		#endregion
	}




	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	//
	// JScheduler
	//		1. Ư�� �Լ�(Action)�� n�� �Ŀ� ȣ��
	//      2. �ֱ��� ������Ʈ �Լ�
	//
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	public class JScheduler
    {
        public static JScheduler Instance = new JScheduler();

        #region [����] JScheduledEvent
        public List<JScheduledEvent> ActiveEvents { get { return m_ActiveEvents; } }

		

		private List<JScheduledEvent> m_ActiveEvents = new List<JScheduledEvent>();
        private List<JScheduledEvent> m_RemoveEvents = new List<JScheduledEvent>();
        private List<Action> m_UpdateObjects = new List<Action>();
        private List<Action> m_RemoveObjects = new List<Action>();
        #endregion




        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // �⺻ �Լ�
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [�ʱ�ȭ] ������
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        // Assign the static variables and register for any events.
        //
        public JScheduler()
        {
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        ~JScheduler()
        {
            m_ActiveEvents.Clear();

		}
        #endregion


        #region [������Ʈ] �ð� �˻��ؼ� �Լ� ȣ��
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Loop through the ScheduledEvents and execute the event when the current time is greater than or equal to the end time of the JScheduledEvent.
        /// </summary>
        public void Update()
        {
            for (int i = m_ActiveEvents.Count - 1; i > -1; --i)
            {
                if (m_ActiveEvents[i].EndTime <= JTimer.GetCurrentTick())
                    Execute(i);
            }

            if (m_RemoveEvents.Count > 0)
            {
                foreach (var remove_event in m_RemoveEvents)
                    m_ActiveEvents.Remove(remove_event);
                m_RemoveEvents.Clear();
            }
            
            for (int i = m_UpdateObjects.Count - 1; i > -1; --i)
                m_UpdateObjects[i]();

            if (m_RemoveObjects.Count > 0)
            {
                foreach (var remove_object in m_RemoveObjects)
                    m_UpdateObjects.Remove(remove_object);
                m_RemoveObjects.Clear();
            }

            execute_mainThreadCommands();
        }
        #endregion

        #region [����] �̺�Ʈ �Լ� ����
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Executes an event with the specified index.
        /// </summary>
        /// <param name="index">The index of the event to execute.</param>
        private void Execute(int index)
        {
            var activeEvent = m_ActiveEvents[index];
            // Remove the event from the list before the callback to prevent the callback from adding a new event and changing the order.
            //m_ActiveEvents.RemoveAt(index);
            m_RemoveEvents.Add(activeEvent);
            if (activeEvent.Callback != null)
            {
                activeEvent.Callback();
            }
            else
            {
                activeEvent.CallbackArg(activeEvent.Argument);
            }
            //ObjectPool.Return(activeEvent);
        }
		#endregion



		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		// Schedule
		//
		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


		#region [Schedule] ���(delay, callback)
		//------------------------------------------------------------------------------------------------------------------------------------------------------
		/// <summary>
		/// Schedule a new event to occur after the specified delay.
		/// </summary>
		/// <param name="delay">The time to wait before triggering the event.</param>
		/// <param name="callback">The event to occur.</param>
		/// <returns>The JScheduledEvent, allows for cancelling.</returns>
		public static JScheduledEvent Schedule(float delay, Action callback)
        {
            if (Instance == null)
            {
                return null;
            }

            return Instance.AddEventInternal(delay, callback);
        }

		public static JScheduledEventExtend ScheduleExtend(float delay, Action callback)
		{
			if (Instance == null)
			{
				return null;
			}

			return Instance.AddExtendEventInternal(delay, callback);
		}
		#endregion

		#region [Schedule] ���(delay, callback, arg)
		/// <summary>
		/// Add a new event with an argumentto be executed in the future.
		/// </summary>
		/// <param name="delay">The delay from the current time to execute the event.</param>
		/// <param name="callback">The delegate to execute after the specified delay.</param>
		/// <param name="arg">The argument of the delegate.</param>
		/// <returns>The JScheduledEvent instance, useful if the event should be cancelled.</returns>
		public static JScheduledEvent Schedule(float delay, Action<object> callback, object arg)
        {
            if (Instance == null)
            {
                return null;
            }

            return Instance.AddEventInternal(delay, callback, arg);
        }
		public static JScheduledEventExtend ScheduleExtend(float delay, Action<object> callback, object arg)
		{
			if (Instance == null)
			{
				return null;
			}

			return Instance.AddExtendEventInternal(delay, callback, arg);
		}
		#endregion

		#region [Schedule] Cancel
		//------------------------------------------------------------------------------------------------------------------------------------------------------
		/// <summary>
		/// Cancels an event.
		/// </summary>
		/// <param name="scheduledEvent">The event to cancel.</param>
		public static void Cancel(ref JScheduledEvent scheduledEvent)
        {
            Instance.CancelEventInternal(ref scheduledEvent);
        }
		public static void Cancel(ref JScheduledEventExtend scheduledEvent)
		{
			Instance.CancelExtendEventInternal(ref scheduledEvent);
		}
		#endregion

		#region [Schedule] [Extend] Pause
		//------------------------------------------------------------------------------------------------------------------------------------------------------
		/// <summary>
		/// Pause an event.
		/// </summary>
		/// <param name="scheduledEvent">The event to pause.</param>
		public static void Pause(JScheduledEventExtend scheduledEvent)
		{
			Instance.PauseEventInternal(scheduledEvent);
		}
		#endregion

		#region [Schedule] [Extend] Continue
		//------------------------------------------------------------------------------------------------------------------------------------------------------
		/// <summary>
		/// Continue an event.
		/// </summary>
		/// <param name="scheduledEvent">The event to continue.</param>
		public static void Continue(JScheduledEventExtend scheduledEvent)
		{
			Instance.ContinueEventInternal(scheduledEvent);
		}
		#endregion


		#region [Schedule] [����] ���
		//------------------------------------------------------------------------------------------------------------------------------------------------------
		/// <summary>
		/// Internal method to add a new event to be executed in the future.
		/// </summary>
		/// <param name="delay">The delay from the current time to execute the event.</param>
		/// <param name="callback">The delegate to execute after the specified delay.</param>
		/// <returns>The JScheduledEvent instance, useful if the event should be cancelled.</returns>
		private JScheduledEvent AddEventInternal(float delay, Action callback)
        {
            // Don't add the event if the game hasn't started.
            //if (enabled == false) {
            //    return null;
            //}

            if (delay == 0)
            {
                callback();
                return null;
            }
            else
            {
                //var scheduledEvent = ObjectPool.Get<JScheduledEvent>();
                var scheduledEvent = new JScheduledEvent();
                scheduledEvent.Reset();
                scheduledEvent.EndTime = JTimer.GetCurrentTick() + JTimer.TimeToTick(delay);
                scheduledEvent.Callback = callback;
                m_ActiveEvents.Add(scheduledEvent);
                return scheduledEvent;
            }
        }
		private JScheduledEventExtend AddExtendEventInternal(float delay, Action callback)
		{
			// Don't add the event if the game hasn't started.
			//if (enabled == false) {
			//    return null;
			//}

			if (delay == 0)
			{
				callback();
				return null;
			}
			else
			{
				//var scheduledEvent = ObjectPool.Get<JScheduledEvent>();
				var scheduledEvent = new JScheduledEventExtend();
				scheduledEvent.Reset();
				scheduledEvent.EndTime = JTimer.GetCurrentTick() + JTimer.TimeToTick(delay);
				scheduledEvent.Callback = callback;
				scheduledEvent.Start();
				m_ActiveEvents.Add(scheduledEvent);
				return scheduledEvent;
			}
		}
		#endregion

		#region [Schedule] [����] ���(arg)
		//------------------------------------------------------------------------------------------------------------------------------------------------------
		/// <summary>
		/// Internal event to add a new event with an argumentto be executed in the future.
		/// </summary>
		/// <param name="delay">The delay from the current time to execute the event.</param>
		/// <param name="callback">The delegate to execute after the specified delay.</param>
		/// <param name="arg">The argument of the delegate.</param>
		/// <returns>The JScheduledEvent instance, useful if the event should be cancelled.</returns>
		private JScheduledEvent AddEventInternal(float delay, Action<object> callbackArg, object arg)
        {
            if (delay == 0)
            {
                callbackArg(arg);
                return null;
            }
            else
            {
                //var scheduledEvent = ObjectPool.Get<JScheduledEvent>();
                var scheduledEvent = new JScheduledEvent();
                scheduledEvent.Reset();
                scheduledEvent.EndTime = JTimer.GetCurrentTick() + JTimer.TimeToTick(delay);
                scheduledEvent.CallbackArg = callbackArg;
                scheduledEvent.Argument = arg;
                m_ActiveEvents.Add(scheduledEvent);
                return scheduledEvent;
            }
        }
		private JScheduledEventExtend AddExtendEventInternal(float delay, Action<object> callbackArg, object arg)
		{
			if (delay == 0)
			{
				callbackArg(arg);
				return null;
			}
			else
			{
				//var scheduledEvent = ObjectPool.Get<JScheduledEvent>();
				var scheduledEvent = new JScheduledEventExtend();
				scheduledEvent.Reset();
				scheduledEvent.EndTime = JTimer.GetCurrentTick() + JTimer.TimeToTick(delay);
				scheduledEvent.CallbackArg = callbackArg;
				scheduledEvent.Argument = arg;
				scheduledEvent.Start();
				m_ActiveEvents.Add(scheduledEvent);
				return scheduledEvent;
			}
		}
		#endregion

		#region [Schedule] [����] Cancel
		//------------------------------------------------------------------------------------------------------------------------------------------------------
		/// <summary>
		/// Internal method to cancel an event.
		/// </summary>
		/// <param name="scheduledEvent">The event to cancel.</param>
		private void CancelEventInternal(ref JScheduledEvent scheduledEvent)
        {
            if (scheduledEvent != null && m_ActiveEvents.Contains(scheduledEvent))
            {
                //m_ActiveEvents.Remove(scheduledEvent);
                m_RemoveEvents.Add(scheduledEvent);
                //ObjectPool.Return(scheduledEvent);
            }
            scheduledEvent = null;
        }
		private void CancelExtendEventInternal(ref JScheduledEventExtend scheduledEvent)
		{
			if (scheduledEvent != null && m_ActiveEvents.Contains(scheduledEvent))
			{
				//m_ActiveEvents.Remove(scheduledEvent);
                m_RemoveEvents.Add(scheduledEvent);
                //ObjectPool.Return(scheduledEvent);
            }
            scheduledEvent = null;
        }
		#endregion

		#region [Schedule] [����] Pause
		//------------------------------------------------------------------------------------------------------------------------------------------------------
		/// <summary>
		/// Internal method to pause an event.
		/// </summary>
		/// <param name="scheduledEvent">The event to pause.</param>
		private void PauseEventInternal(JScheduledEventExtend scheduledEvent)
		{
			if (scheduledEvent != null && m_ActiveEvents.Contains(scheduledEvent))
			{
				scheduledEvent.Pause();
				m_ActiveEvents.Remove(scheduledEvent);
				//ObjectPool.Return(scheduledEvent);
			}
		}
		#endregion

		#region [Schedule] [����] Continue
		//------------------------------------------------------------------------------------------------------------------------------------------------------
		/// <summary>
		/// Internal method to continue an event.
		/// </summary>
		/// <param name="scheduledEvent">The event to continue.</param>
		private void ContinueEventInternal(JScheduledEventExtend scheduledEvent)
		{
			if (scheduledEvent != null && m_ActiveEvents.Contains(scheduledEvent))
			{
				scheduledEvent.Continue();
				m_ActiveEvents.Add(scheduledEvent);
				//ObjectPool.Return(scheduledEvent);
			}
		}
        #endregion


        #region [Schedule] Async wait (����� �ʿ�)
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static async Task Wait(float duration)
        {
            var tcs = new TaskCompletionSource<bool>();
            Schedule(duration, () =>
            {
                tcs.SetResult(true);                
            });
            var result = await tcs.Task;            
        }
        #endregion



        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // Updatable
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [Updatable] ���
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void AddUpdatable(Action callback)
        {
            if (Instance == null)
                return;
            Instance.m_UpdateObjects.Add(callback);
        }
        #endregion
        
        #region [Updatable] ���
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void CancelUpdatable(Action callback)
        {
            if (Instance == null)
                return;
            Instance.m_RemoveObjects.Add(callback);
        }
        #endregion


        
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // [���ξ�����] Commands
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [����] Commands
        internal static readonly NetQueue<Action> _commands_main_thred = new NetQueue<Action>(8);
        #endregion


        #region [���ξ�����] [Commands] �߰�
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void AddMainThreadCommand(Action fun)
        {
            _commands_main_thred.Enqueue(fun);
        }
        #endregion

        #region [���ξ�����] [Commands] ����
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        protected static void execute_mainThreadCommands()
        {
            while (_commands_main_thred.Count > 0)
            {
                if (_commands_main_thred.TryDequeue(out Action command))
                    command();
            }
        }
        #endregion

    }

}
