﻿using System.Collections.Generic;
using System.Linq;
﻿using System;
﻿using System.IO;
﻿using UnityEngine;
﻿using Random = UnityEngine.Random;
using System.Xml.Serialization;

namespace J2y
{
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //
    // JUtil
    //
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    public partial class JUtil : MonoBehaviour
    {
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // Base
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        
        #region [로그] Write
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void WriteLog(string log, params object[] args)
        {
            Console.WriteLine(string.Format(log, args));
        }

        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void Log(string text, Vector3 savePosition)
        {
            Console.WriteLine(string.Format("{0}({1:0.0}, {2:0.0}, {3:0.0})", text, savePosition.x, savePosition.y, savePosition.z));
        }
        #endregion

        #region [유니크 ID]
        private static long s_uniqueIndex = 1;

        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static long CreateUniqueId()
        {
            s_uniqueIndex++;
            var curTick = DateTime.Now.Ticks + s_uniqueIndex;
            return curTick;
        }
        #endregion


        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // GameObject / Transform
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [GameObject] Create
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static GameObject CreateGameObject(string name, Transform parentTM = null)
        {
            //var prefab = (GameObject)Resources.Load(filename);
            //var go = (GameObject)GameObject.Instantiate(prefab);
            var go = new GameObject(name);
            if (parentTM != null)
                go.transform.parent = parentTM;

            //Resources.UnloadAsset(prefab); // 테스트 필요
            return go;
        }
        #endregion

        #region [Transform] Reset/Hierarchy
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void ResetTransform(Transform tm)
        {
            tm.localPosition = Vector3.zero;
            tm.localRotation = Quaternion.identity;
            tm.localScale = Vector3.one;
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void SetParent(GameObject parentGO, GameObject childGO)
        {
            childGO.transform.parent = parentGO.transform;
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void SetParent(Transform parentTM, Transform childTM)
        {
            childTM.parent = parentTM;
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void DestroyAllChildren(GameObject parentGO)
        {
            DestroyAllChildren(parentGO.transform);
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void DestroyAllChildren(Transform parentTM)
        {
            foreach (Transform child in parentTM)
            {
                GameObject.Destroy(child.gameObject);
            }
        }
        #endregion
        
        #region [Transform] Find
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static Transform FindTransform(Transform parentTM, string objName)
        {
            if (parentTM == null) return null;

            foreach (Transform trans in parentTM)
            {
                if (trans.name == objName)
                {
                    return trans;
                }

                Transform foundTransform = FindTransform(trans, objName);
                if (foundTransform != null)
                {
                    return foundTransform;
                }
            }

            return null;
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static Transform FindTransform(GameObject parentObj, string objName)
        {
            return FindTransform(parentObj.transform, objName);
        }
        #endregion


        

        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // mathematics
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [수학]

        //------------------------------------------------------------------------------------------------------------------------------------------------------
        // 이런 함수 없나??	
        public static void Swap<T>(ref T x, ref T y)
        {
            T temp;
            temp = x; x = y; y = temp;
        }

        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static float Distance2d(Vector3 a, Vector3 b)
        {
            return Mathf.Sqrt((a.x - b.x) * (a.x - b.x) + (a.z - b.z) * (a.z - b.z));
        }



        //------------------------------------------------------------------------------------------------------------------------------------------------------
        // [0, 1] -> [0, 1](Smooth)
        public static float SmoothLerp2(float t)
        {
            float percentage = 0.5f + Mathf.Sin(t * Mathf.PI - (Mathf.PI * 0.5f)) * 0.5f;
            //percentage = Mathf.Clamp01(percentage);
            return percentage;
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static float SmoothLerp(float t)
        {
            return Mathf.Clamp01(Mathf.Sin(t * 90f));
        }


        //------------------------------------------------------------------------------------------------------------------------------------------------------
        // sin[-1, 1] -> sin[0, 1]
        public static float Sin01(float t)
        {
            return Mathf.Sin(t) * 0.5f + 0.5f;
        }

        //------------------------------------------------------------------------------------------------------------------------------------------------------
        // sphere1과 sphere2의 충돌 검사를 한다.
        // 리턴값이 트루일 경우 t초에 충돌한다.
        public static bool SphereCollisionDetect(Vector3 v1, Vector3 p1, float r1,
            Vector3 v2, Vector3 p2, float r2, ref float t)
        {
            Vector3 s = p1 - p2;        // vector between the centers of each sphere
            Vector3 v = v1 - v2;        // relative velocity between spheres
            float r = r1 + r2;

            float c1 = Vector3.Dot(s, s) - r * r; // if negative, they overlap
            if (c1 < 0.0) // if true, they already overlap
            {
                // This is bad ... we need to correct this by moving them a tiny fraction from each other
                //a->pos +=
                t = 0.0f;
                return true;
            }

            float a1 = Vector3.Dot(v, v);
            if (a1 < 0.00001f)
                return false; // does not move towards each other

            float b1 = Vector3.Dot(v, s);
            if (b1 >= 0.0)
                return false; // does not move towards each other

            float d1 = b1 * b1 - a1 * c1;
            if (d1 < 0.0)
                return false; // no real roots ... no collision

            t = (-b1 - Mathf.Sqrt(d1)) / a1;

            return true;
        }
        
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static int GetMax(int[] array, ref int index, int cheak = 99)
        {
            int max = 0;
            var tmp = index;
            index = 0;

            for (int i = 0; i < array.Length; i++)
            {
                if (max < array[i] && i != cheak)
                {
                    max = array[i];
                    index = i;
                }
            }
            return max;
        }
        #endregion
        
        #region [메모리] Memset
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void Memset(int[] target, int value)
        {
            Memset(target, value, target.Length);
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void Memset(int[] target, int value, int count)
        {
            int i;
            int blockSize = Math.Min(1024, count);

            for (i = 0; i < blockSize; i++)
                target[i] = value;

            if (i == count)
                return;

            int bytesCount = blockSize * sizeof(int);

            while (i + blockSize < count)
            {
                Buffer.BlockCopy(target, 0, target, i, bytesCount);
                i += blockSize;
            }

            bytesCount = (count - i) * sizeof(int);
            Buffer.BlockCopy(target, 0, target, i, bytesCount);
        }
        #endregion

        #region [수학] Frame <-> Time
        public static float FrameToTime(int frame)
        {
            return (float)frame / 30f;
        }
        public static int TimeToFrame(float time)
        {
            return (int)(time * 30f);
        }
        #endregion

        #region [유틸] 비트 플래그
        public static class FlagsHelper
        {
            public static bool IsSet<T>(int flags, T flag) where T : struct
            {
                int flagsValue = flags;
                int flagValue = 1 << (int)(object)flag;

                return (flagsValue & flagValue) != 0;
            }

            public static void Set<T>(ref int flags, T flag) where T : struct
            {
                int flagsValue = flags;
                int flagValue = 1 << (int)(object)flag;

                flags = (int)(object)(flagsValue | flagValue);
            }

            public static void Unset<T>(ref int flags, T flag) where T : struct
            {
                int flagsValue = flags;
                int flagValue = 1 << (int)(object)flag;

                flags = (int)(object)(flagsValue & (~flagValue));
            }
        }
        #endregion

        #region [유틸] Color <-> Int
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static Color IntToColor(int c)
        {
            var r = (float)((c >> 16) & 0xff);
            var g = (float)((c >> 8) & 0xff);
            var b = (float)(c & 0xff);
            return new Color(r / 255f, g / 255f, b / 255f);
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static Color32 IntToColor32(int c)
        {
            var r = (byte)((c >> 16) & 0xff);
            var g = (byte)((c >> 8) & 0xff);
            var b = (byte)(c & 0xff);
            return new Color32(r, g, b, 255);
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static int ColorToInt(Color32 c)
        {
            var ci = (c.r >> 16) | (c.g >> 16) | (c.b);
            return ci;
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static int ColorToInt(Color c)
        {
            return ColorToInt((Color32)c);
        }
        #endregion

        #region [수학] Vector3
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static Vector3 MakeDirection(Vector3 p1, Vector3 p2)
        {
            return (p2 - p1).normalized;
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static Vector3 MakeDirectionXZ(Vector3 p1, Vector3 p2)
        {
            var dir = new Vector3(p2.x - p1.x, 0f, p2.z - p1.z);
            return dir.normalized;
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static Vector3 MakeDirectionXZ(Vector3 p, bool normalize = false)
        {
            p = new Vector3(p.x, 0f, p.z);
            if (normalize)
                p.Normalize();
            return p;
        }
        #endregion

        #region [KeyValuePair] Make
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static KeyValuePair<K, U> MakePair<K, U>()
        {
            return new KeyValuePair<K, U>();
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static KeyValuePair<K, U> MakePair<K, U>(K key, U value)
        {
            return new KeyValuePair<K, U>(key, value);
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static KeyValuePair<string, U> MakePair<U>(string key) where U : new()
        {
            return new KeyValuePair<string, U>(key, new U());
        }
        #endregion

        
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // 확률
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [랜덤] Values (Unity3D)
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void RandomValues(int[] recordTime, int min, int max)
        {
            for (var i = 0; i < recordTime.Length; ++i)
                recordTime[i] = Random.Range(min, max);
        }
        public static Vector3 RandomRange(Vector3 center, Vector3 size)
        {
            return center + RandomVector3(size);
        }
        public static Vector3 RandomRange(Vector3 center, float size_x, float size_z)
        {
            return center + RandomVector3(size_x, size_z);
        }
        public static Vector3 RandomVector3(Vector3 size)
        {
            return new Vector3(
               (Random.value - 0.5f) * size.x,
               (Random.value - 0.5f) * size.y,
               (Random.value - 0.5f) * size.z
            );
        }
        public static Vector3 RandomVector3(float size_x, float size_z)
        {
            var v3 = new Vector3(
               (Random.value - 0.5f) * size_x,
               0f,
               (Random.value - 0.5f) * size_z
            );
            return v3;
        }
        public static Vector3 RandomRange(BoxCollider box)
        {
            return RandomRange(box.center, box.size);
        }
        #endregion

        #region [랜덤] Values (System)
        static System.Random _random = new System.Random((int)DateTime.Now.Ticks);

        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static float RandomRange(float min, float max)
        {
            if (min == max)
                return min;
            var r = min + (float)_random.NextDouble() * (max - min);
            return r;
        }
        public static int RandomRange(int min, int max)
        {
            if (min == max)
                return min;
            int r = min + _random.Next() % (max - min);
            return r;
        }

       
        #endregion

        #region [랜덤] Shuffle
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void Shuffle<T>(T[] array)
        {
            Shuffle(array, array.Length * 2);
        }

        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void Shuffle<T>(T[] array, int count)
        {
            int arrayLen = array.Length;
            Shuffle(array, arrayLen, count);
        }

        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void Shuffle<T>(T[] array, int arrayLen, int count)
        {
            while (count > 1)
            {
                int k1 = RandomRange(0, arrayLen); // 0 <= k < n.
                int k2 = RandomRange(0, arrayLen); // 0 <= k < n.
                count--;
                T temp = array[k1];
                array[k1] = array[k2];
                array[k2] = temp;
            }
        }
        #endregion

        

        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // Serialize
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [Serialize] XML
        //------------------------------------------------------------------------------------------------------------------------------------------------------	
        public static void Serialize(string filename, System.Object o)
        {
            var writer = new XmlSerializer(o.GetType());
            var wfile = new System.IO.StreamWriter(filename);
            writer.Serialize(wfile, o);
            wfile.Close();
        }
        #endregion

        #region [Deserialize] XML
        //------------------------------------------------------------------------------------------------------------------------------------------------------	
        public static T Deserialize<T>(string filename)
        {
            var reader = new XmlSerializer(typeof(T));
            var file = new StreamReader(filename);
            var obj = (T)reader.Deserialize(file);
            file.Close();
            return obj;
        }
        #endregion

        #region [유틸] EMail 전송
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public void SendEMail(string mail_sender, string mail_receiver, string subject, string body)
        {
            System.Net.Mail.MailMessage message = new System.Net.Mail.MailMessage();
            message.To.Add(mail_receiver);
            message.Subject = subject;
            message.From = new System.Net.Mail.MailAddress(mail_sender);
            message.Body = body;
            System.Net.Mail.SmtpClient smtp = new System.Net.Mail.SmtpClient("yoursmtphost");
            smtp.Send(message);
        }
        #endregion


        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // FileSystem
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region 경로 문제
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public string pathForDocumentsFile(string filename)
        {
            if (Application.platform == RuntimePlatform.IPhonePlayer)
            {
                string path = Application.dataPath.Substring(0, Application.dataPath.Length - 5);
                path = path.Substring(0, path.LastIndexOf('/'));
                return Path.Combine(Path.Combine(path, "Documents"), filename);
            }

            else if (Application.platform == RuntimePlatform.Android)
            {
                string path = Application.persistentDataPath;
                path = path.Substring(0, path.LastIndexOf('/'));
                return Path.Combine(path, filename);
            }

            else
            {
                string path = Application.dataPath;
                path = path.Substring(0, path.LastIndexOf('/'));
                return Path.Combine(path, filename);
            }
        }
        #endregion
        
        #region 폴더
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void CreateFolder(string folder)
        {
            var di = new DirectoryInfo(folder);
            if (di.Exists == false)
                di.Create();
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static bool ExistsFolder(string folder)
        {
            var di = new DirectoryInfo(folder);
            return di.Exists;
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void DeleteFolder(string folder, bool recursive)
        {
            var di = new DirectoryInfo(folder);
            if (di.Exists)
                di.Delete(recursive);
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void DirectoryCopy(string sourceDirName, string destDirName, bool copySubDirs)
        {
            // Get the subdirectories for the specified directory.
            DirectoryInfo dir = new DirectoryInfo(sourceDirName);
            DirectoryInfo[] dirs = dir.GetDirectories();

            if (!dir.Exists)
            {
                throw new DirectoryNotFoundException(
                    "Source directory does not exist or could not be found: "
                    + sourceDirName);
            }

            // If the destination directory doesn't exist, create it. 
            if (!Directory.Exists(destDirName))
            {
                Directory.CreateDirectory(destDirName);
            }

            // Get the files in the directory and copy them to the new location.
            FileInfo[] files = dir.GetFiles();
            foreach (FileInfo file in files)
            {
                string temppath = Path.Combine(destDirName, file.Name);
                file.CopyTo(temppath, true);
            }

            // If copying subdirectories, copy them and their contents to new location. 
            if (copySubDirs)
            {
                foreach (DirectoryInfo subdir in dirs)
                {
                    string temppath = Path.Combine(destDirName, subdir.Name);
                    DirectoryCopy(subdir.FullName, temppath, copySubDirs);
                }
            }
        }

        #endregion


        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // Unity3D
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [Unity3D] Layer 
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void MoveToLayer(Transform root, string layerName)
        {
            int layer = LayerMask.NameToLayer(layerName);
            MoveToLayer(root, layer);
        }

        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void MoveToLayer(Transform root, int layer)
        {
            root.gameObject.layer = layer;
            foreach (Transform child in root)
                MoveToLayer(child, layer);
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void SetLayer(GameObject root, string layerName)
        {
            int layer = LayerMask.NameToLayer(layerName);
            root.layer = layer;
            foreach (Transform child in root.transform)
                MoveToLayer(child, layer);
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void SetLayer(Transform root, string layerName)
        {
            SetLayer(root.gameObject, layerName);
        }
        #endregion
        
        #region [Unity3D] 셰이더 리셋
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        //public static void Reset_shaders(Renderer[] renderers)
        //{		
        //	var dict = new Dictionary<Material, Material>();

        //	foreach (var rs in renderers)
        //	{
        //		foreach (var mtrl in rs.sharedMaterials)
        //			if ((mtrl != null) && !dict.ContainsKey(mtrl))
        //				dict[mtrl] = mtrl;
        //	}

        //	foreach (var mtrl in dict.Values)
        //		mtrl.shader = Shader.Find(mtrl.shader.name);		
        //}

        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void Reset_shaders(Renderer[] renderers)
        {
            // 중국 버전 보류
            //foreach (var rs in renderers)
            //{
            //    //var thisMaterial = rs.sharedMaterials;
            //    //var shaders = new string[thisMaterial.Length];

            //    //for (int i = 0; i < thisMaterial.Length; i++)
            //    //{
            //    //	if(thisMaterial[i] != null)
            //    //		shaders[i] = thisMaterial[i].shader.name;
            //    //}

            //    //for (int i = 0; i < thisMaterial.Length; i++)
            //    //{
            //    //	if(shaders[i] != null)
            //    //		thisMaterial[i].shader = Shader.Find(shaders[i]);
            //    //}       

            //    foreach (var mtrl in rs.sharedMaterials)
            //        if (mtrl != null && mtrl.shader != null && mtrl.shader.name != null)
            //            mtrl.shader = Shader.Find(mtrl.shader.name);
            //}
        }
        #endregion

        #region [Unity3D] 물리/충돌
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static bool Raycast_screenPoint(Vector3 scnPos, out RaycastHit hit, string layerName)
        {
            int layer = 0;
            if (layerName == "")
                layer = ~0;
            else
                layer = 1 << LayerMask.NameToLayer(layerName);

            if (Physics.Raycast(Camera.main.ScreenPointToRay(scnPos), out hit, 9999f, layer))
                return true;

            return false;
        }
        #endregion


        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // 보류
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [보류] fade in/out

        //private Texture2D _fadeOutTexture;
        //public float _fadeSpeed = 0.6f;
        //private float _fadeAlpha = 0.0f;
        //private float _fadeDir = -1.0f;

        //private void loadImages()
        //{
        //    // 이미지 숫자
        //    _fadeOutTexture = Resources.Load("GUI/Black") as Texture2D;

        //    Console.WriteLine("Util.loadImages");
        //}


        ////------------------------------------------------------------------------------------------------------------------------------------------------------
        //public void FadeOut()
        //{
        //    _fadeDir = 1.0f;
        //}
        //public void FadeIn()
        //{
        //    _fadeDir = -1.0f;
        //}
        //public void UpdateFadeInOut()
        //{
        //    int oldDepth = GUI.depth;
        //    GUI.depth = -10;
        //    _fadeAlpha += _fadeDir * _fadeSpeed * Time.deltaTime;
        //    _fadeAlpha = Mathf.Clamp01(_fadeAlpha);

        //    Color c = GUI.color;
        //    c.a = _fadeAlpha;
        //    GUI.color = c;
        //    if (_fadeAlpha > 0)
        //        GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), _fadeOutTexture);
        //    GUI.depth = oldDepth;
        //}
        #endregion

    }



    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // Helper
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region [Helper] Lerp

    public class LerpHelper
    {
        private float _time;
        private float _prevValue;
        public float _target;

        public void SetTarget(float startValue, float target)
        {
            _prevValue = startValue;
            _target = target;
            _time = 0.0f;
        }

        public float Lerp(float dt)
        {
            _time = Mathf.Clamp01(_time + dt);
            Value = Mathf.Lerp(_prevValue, _target, _time);
            return Value;
        }

        public float Value { get; private set; }
    }
    #endregion

    #region [Helper] Timer
    public class TimerHelper
    {
        private float _time;
        private float _interval;

        public TimerHelper(float interval)
        {
            _interval = interval;
        }

        public bool Update(float dt)
        {
            _time += dt;
            if (_time > _interval)
            {
                _time = _time % _interval;
                return true;
            }

            return false;
        }
    }
    #endregion



    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // Extensions
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region [Extensions] String
    public static class StringExtensions
    {
        public static Vector3 ToVector3(this string str)
        {
            var output = new Vector3();
            var split = str.Replace("(", "").Replace(")", "").Split(',');
            if (!float.TryParse(split[0], out output.x) || !float.TryParse(split[1], out output.y) || !float.TryParse(split[2], out output.z))
                return Vector3.zero;

            return output;


        }
    }
    #endregion

    #region [Extensions] Dictionary
    public static class DictionaryExtensions
    {
        public static void RemoveAll<TKey, TValue>(this IDictionary<TKey, TValue> dic,
            Func<TValue, bool> predicate)
        {
            var keys = dic.Keys.Where(k => predicate(dic[k])).ToList();
            foreach (var key in keys)
            {
                dic.Remove(key);
            }
        }
    }
    #endregion
    
    #region [Extensions] List
    public static class ListExtensions
    {
        //    list: List<T> to resize
        //    size: desired new size
        // element: default value to insert

        public static void Resize<T>(this List<T> list, int size, T element = default(T))
        {
            int count = list.Count;

            if (size < count)
            {
                list.RemoveRange(size, count - size);
            }
            else if (size > count)
            {
                if (size > list.Capacity)   // Optimization
                    list.Capacity = size;

                list.AddRange(Enumerable.Repeat(element, size - count));
            }
        }
    }
    #endregion


    #region [Extensions] GameObject
    public static class GameObjectExtensions
    {
        #region [GameObject] GetOrAddComponent
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static T GetOrAddComponent<T>(this GameObject parentGO) where T : Component
        {
            var com = parentGO.GetComponent<T>();
            if (null == com)
                com = parentGO.AddComponent<T>();
            return com;
        }
        #endregion
    }
    #endregion


    #region [Interface] Prototype
    public abstract class Prototype
    {
        public abstract Prototype Clone();
    }
    #endregion

}
