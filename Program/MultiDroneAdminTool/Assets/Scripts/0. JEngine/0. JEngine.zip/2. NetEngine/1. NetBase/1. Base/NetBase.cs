﻿using System;
using System.Collections.Generic;

namespace J2y.Network
{

    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //
    // enum
    //
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region [enum] NetSendResult
    public enum eNetSendResult
    {
        /// <summary>
        /// Message failed to enqueue because there is no connection
        /// </summary>
        FailedNotConnected = 0,

        /// <summary>
        /// Message was immediately sent
        /// </summary>
        Sent = 1,

        /// <summary>
        /// Message was queued for delivery
        /// </summary>
        Queued = 2,

        /// <summary>
        /// Message was dropped immediately since too many message were queued
        /// </summary>
        Dropped = 3,

        UnknownError = 4,
    }
    #endregion

    #region [enum] NetConnectionStatus
    public enum eNetConnectionStatus
    {
        /// <summary>
        /// No connection, or attempt, in place
        /// </summary>
        None,

        /// <summary>
        /// Connect has been sent; waiting for ConnectResponse
        /// </summary>
        InitiatedConnect,

        /// <summary>
        /// Connect was received, but ConnectResponse hasn't been sent yet
        /// </summary>
        ReceivedInitiation,

        /// <summary>
        /// Connect was received and ApprovalMessage released to the application; awaiting Approve() or Deny()
        /// </summary>
        RespondedAwaitingApproval, // We got Connect, released ApprovalMessage

        /// <summary>
        /// Connect was received and ConnectResponse has been sent; waiting for ConnectionEstablished
        /// </summary>
        RespondedConnect, // we got Connect, sent ConnectResponse

        /// <summary>
        /// Connected
        /// </summary>
        Connected,        // we received ConnectResponse (if initiator) or ConnectionEstablished (if passive)

        /// <summary>
        /// In the process of disconnecting
        /// </summary>
        Disconnecting,

        /// <summary>
        /// Disconnected
        /// </summary>
        Disconnected
    }
    #endregion

    #region [enum] FileTransferState
    public enum eFileTransferState
    {
        Start, Chunks, End,
    }
    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //
    // JNetMessageProtocol
    //
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region [Constant] JNetMessageProtocol

    //------------------------------------------------------------------------------------------------------------------------------------------------------
    public static class JNetMessageProtocol
    {
        public static byte None = 0;                    // None
        public static byte SimpleMessage = 1;           // [S<->C] 자주 사용하는 간단한 메시지
        public static byte FileTransfer = 2;            // [S<->C] File Transfer
        public static byte RPC = 3;                     // [S<->C] RPC

    }
    #endregion



    
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //
    // NetBase
    //      
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    internal static class NetBase
	{
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // Constant
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


        #region [상수] Buffer Size
        public const int HeaderByteSize = 16;
        //public const int NetworkMTU = 1408;
        public const int NetworkMTU = 1024 * 1024;
        public const long SendMTUMaxTime = 500;                       // ms, 최대 누적시간
        public const int MaxReceiveBufferSize = 1024 * 1024 * 10;     // 10 MB (최대 전송 버퍼)
        public const int FileChunkSize = 573330;

        //internal const int DefaultSendBufferSize = 1024;              // 1 KB
        //internal const int MaxSendBufferSize = 1024 * 1024 * 10;      // 10 MB

        #endregion

        #region [백업] [상수] Constant
        internal const int NumTotalChannels = 99;
        internal const int NetChannelsPerDeliveryMethod = 32;
        internal const int NumSequenceNumbers = 1024;

        internal const int UnreliableWindowSize = 128;
        internal const int ReliableOrderedWindowSize = 64;
        internal const int ReliableSequencedWindowSize = 64;
        internal const int DefaultWindowSize = 64;

        internal const int MaxFragmentationGroups = ushort.MaxValue - 1;

        internal const int UnfragmentedMessageHeaderSize = 5;

        ///// <summary>
        ///// Number of channels which needs a sequence number to work
        ///// </summary>
        //internal const int NumSequencedChannels = ((int)NetMessageType.UserReliableOrdered1 + NetBase.NetChannelsPerDeliveryMethod) - (int)NetMessageType.UserSequenced1;

        ///// <summary>
        ///// Number of reliable channels
        ///// </summary>
        //internal const int NumReliableChannels = ((int)NetMessageType.UserReliableOrdered1 + NetBase.NetChannelsPerDeliveryMethod) - (int)NetMessageType.UserReliableUnordered;

        internal const string ConnResetMessage = "Connection was reset by remote host";



        // Maximum transmission unit
        // Ethernet can take 1500 bytes of payload, so lets stay below that.
        // The aim is for a max full packet to be 1440 bytes (30 x 48 bytes, lower than 1468)
        // -20 bytes IP header
        //  -8 bytes UDP header
        //  -4 bytes to be on the safe side and align to 8-byte boundary
        // Total 1408 bytes

        /// <summary>
        /// Default MTU value in bytes
        /// </summary>

        public static int MaxIOThreadCount = 10;
        #endregion



        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // 유틸
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [유틸] 패킷 유효성 검사
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static bool ValidPacket(NetMessageHeader header)
		{
			return true;
		}
		#endregion

		#region [유틸] Check Sum 계싼
		//------------------------------------------------------------------------------------------------------------------------------------------------------
		public static byte MakeChecksum(byte[] send_buf)
		{
			byte checkSum = 0;
			foreach (var ch in send_buf)
				checkSum += (byte)ch;

			return checkSum;
		}
        #endregion


        #region [사용X] [유틸] 쓰레드 개수
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static List<int> _threadIds = new List<int>();
        static object _lock_threads = new object();
        public static void AddThreadID(int threadId)
        {
            lock (_lock_threads)
            {
                if (!_threadIds.Contains(threadId))
                {
                    _threadIds.Add(threadId);
                    Console.WriteLine("IO Thread Count : {0}", _threadIds.Count);
                }
            }
        }
        #endregion


    }
}
