using UnityEngine;
using System.Collections.Generic;
using System;
using System.Reflection;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;


namespace J2y
{
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //
    // JNetData_base
    //
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    [Serializable]
    public class JNetData_base
    {
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // [IO ������] �޽��� ��ŷ/�Ľ�
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [IO ������] �޽��� ��ŷ
        //----------------------------------------------------------------
        public virtual void Read(BinaryReader reader)
        {
        }
        #endregion

        #region [IO ������] �޽��� �Ľ�
        //----------------------------------------------------------------
        public virtual void Write(BinaryWriter writer)
        {
        }
        #endregion

        #region [���̽�] Clone
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public virtual object Clone()
        {
            var netdata = (JNetData_base)this.MemberwiseClone();
            return netdata;
        }

        #endregion



        #region [���]] �޽��� ��ŷ/�Ľ�



        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // ��ƿ
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [��ƿ] �Ľ�
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public void ParseArray<T>(BinaryReader reader, ref T[] buffer, bool null_check = false) where T : JNetData_base, new()
        {
            for (int i = 0; i < buffer.Length; i++)
            {
                bool read_data = true;
                if (null_check)
                    read_data = reader.ReadBoolean();

                if (read_data)
                {
                    var data = new T();
                    data.Read(reader);
                    buffer[i] = data;
                }
            }
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public void ParseList<T>(BinaryReader reader, List<T> buffer) where T : JNetData_base, new()
        {
            buffer.Clear();
            int count = reader.ReadInt32();
            for (int i = 0; i < count; i++)
            {
                var data = new T();
                data.Read(reader);
                buffer.Add(data);
            }
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public void ParseDictionaryLong<T2>(BinaryReader reader, out IDictionary<long, T2> buffer) where T2 : JNetData_base, new()
        {
            buffer = new Dictionary<long, T2>();
            buffer.Clear();
            int count = reader.ReadInt32();
            for (int i = 0; i < count; i++)
            {
                var key = reader.ReadInt64();
                var data = new T2();
                data.Read(reader);
                buffer.Add(key, data);
            }
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public void ParseDictionaryInt<T2>(BinaryReader reader, out IDictionary<int, T2> buffer) where T2 : JNetData_base, new()
        {
            buffer = new Dictionary<int, T2>();
            buffer.Clear();
            int count = reader.ReadInt32();
            for (int i = 0; i < count; i++)
            {
                var key = reader.ReadInt32();
                var data = new T2();
                data.Read(reader);
                buffer.Add(key, data);
            }
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public void ParseIntArray(BinaryReader reader, ref int[] buffer)
        {
            for (int i = 0; i < buffer.Length; ++i)
                buffer[i] = reader.ReadInt32();
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public void ParseLongArray(BinaryReader reader, ref long[] buffer)
        {
            for (int i = 0; i < buffer.Length; ++i)
                buffer[i] = reader.ReadInt64();
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public void ParseIntList(BinaryReader reader, List<int> buffer)
        {
            buffer.Clear();
            int count = reader.ReadInt32();
            for (int i = 0; i < count; i++)
                buffer.Add(reader.ReadInt32());
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public void ParseLongList(BinaryReader reader, List<long> buffer)
        {
            buffer.Clear();
            int count = reader.ReadInt32();
            for (int i = 0; i < count; i++)
                buffer.Add(reader.ReadInt64());
        }
        #endregion

        #region [��ƿ] ��ŷ
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public void PackingArray(BinaryWriter writer, JNetData_base[] buffer, bool null_check = false)
        {
            foreach (var data in buffer)
            {
                if (null_check)
                    writer.Write(data != null);
                if (data != null)
                    data.Write(writer);
            }
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public void PackingList<T>(BinaryWriter writer, List<T> buffer) where T : JNetData_base
        {
            writer.Write(buffer.Count);
            foreach (var data in buffer)
                data.Write(writer);
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public void PackingDictionaryLong<T2>(BinaryWriter writer, IDictionary<long, T2> buffer)
            where T2 : JNetData_base
        {
            writer.Write(buffer.Count);
            foreach (var data in buffer)
            {
                writer.Write(data.Key);
                data.Value.Write(writer);
            }
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public void PackingDictionaryInt<T2>(BinaryWriter writer, IDictionary<int, T2> buffer)
            where T2 : JNetData_base
        {
            writer.Write(buffer.Count);
            foreach (var data in buffer)
            {
                writer.Write(data.Key);
                data.Value.Write(writer);
            }
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public void PackingIntArray(BinaryWriter writer, int[] buffer)
        {
            foreach (var data in buffer)
                writer.Write(data);
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public void PackingLongArray(BinaryWriter writer, long[] buffer)
        {
            foreach (var data in buffer)
                writer.Write(data);
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public void PackingIntList(BinaryWriter writer, List<int> buffer)
        {
            writer.Write(buffer.Count);
            foreach (var data in buffer)
                writer.Write(data);
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public void PackingLongList(BinaryWriter writer, List<long> buffer)
        {
            writer.Write(buffer.Count);
            foreach (var data in buffer)
                writer.Write(data);
        }
        #endregion


        #region [��ƿ] Vector2, Vector3
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void Write(BinaryWriter writer, Vector3 v)
        {
            writer.Write(v.x);
            writer.Write(v.y);
            writer.Write(v.z);
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void Write(BinaryWriter writer, Vector2 v)
        {
            writer.Write(v.x);
            writer.Write(v.y);
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static Vector3 ReadVector3(BinaryReader recv_msg)
        {
            var v = new Vector3();
            v.x = recv_msg.ReadSingle();
            v.y = recv_msg.ReadSingle();
            v.z = recv_msg.ReadSingle();
            return v;
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static Vector2 ReadVector2(BinaryReader recv_msg)
        {
            var v = new Vector2();
            v.x = recv_msg.ReadSingle();
            v.y = recv_msg.ReadSingle();
            return v;
        }
        #endregion
        #endregion

    }


}
