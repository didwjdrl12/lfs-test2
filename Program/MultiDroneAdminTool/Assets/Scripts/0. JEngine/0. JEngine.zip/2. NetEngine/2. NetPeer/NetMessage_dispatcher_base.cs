using System;
using System.Collections.Generic;
using System.IO;


namespace J2y.Network
{
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	//
	// NetMessage_dispatcher_base
	//
	//
	//
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	public class NetMessage_dispatcher_base
	{

		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		// ����
		//
		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

		#region [����] �޽��� �ڵ鷯

		protected NetPeer_base _netpeer;
		protected Dictionary<int, Action<NetPeer_base, BinaryReader>> _message_handlers;
        protected Dictionary<string, Action<NetPeer_base, BinaryReader>> _simple_message_handlers;                                                                                                          

        #endregion



        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // ���� �Լ�
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [�ʱ�ȭ] ������
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public NetMessage_dispatcher_base(NetPeer_base netpeer)
		{
			_netpeer = netpeer;
			_message_handlers = new Dictionary<int, Action<NetPeer_base, BinaryReader>>();
            _simple_message_handlers = new Dictionary<string, Action<NetPeer_base, BinaryReader>>();

            register_base_message_handlers();
        }
        #endregion

        #region [�ڵ鷯] �⺻ �޽��� �ڵ鷯 ���(����, RPC)
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        protected virtual void register_base_message_handlers()
        {
            // �⺻ ���� ���� �ڵ鷯 ���
            RegisterMessageHandler(JNetMessageProtocol.FileTransfer, (peer, reader) =>
            {
                peer.OnRecv_FileTransfer(reader);
            });
            RegisterMessageHandler(JNetMessageProtocol.RPC, (peer, reader) =>
            {
                JRPCMediator.OnNetRecvRPC(peer, reader);
            });
        }
        #endregion


        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++led++++++++++++++++++++++++++++++++++++++++++
        // �ݸ޽��� ����ġ
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [�޽��� �ڵ鷯] ���
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public virtual void RegisterMessageHandler(int id, Action<NetPeer_base, BinaryReader> handler, bool overwrite = false)
		{
			if (_message_handlers.ContainsKey(id))
			{
				if (overwrite)
					_message_handlers[id] = handler;
            }
			else
			{
				_message_handlers.Add(id, handler);
			}
		}
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public virtual void UnregisterMessageHandler(int id)
        {
            if (_message_handlers.ContainsKey(id))
            {
                _message_handlers.Remove(id);
            }
        }
        #endregion

        #region [�޽��� �ڵ鷯] [Simple] ���        
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public virtual void RegisterSimpleMessageHandler(string id, Action<NetPeer_base, BinaryReader> handler, bool overwrite = false)
        {
            if (_simple_message_handlers.ContainsKey(id))
            {
                if (overwrite)
                    _simple_message_handlers[id] = handler;
            }
            else
            {
                _simple_message_handlers.Add(id, handler);
            }
        }
        #endregion

        #region [����ġ] �޽���
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public void DispatchMessages(NetPeer_base sender, int message_type, NetBuffer net_buffer, BinaryReader reader)
		{
			Action<NetPeer_base, BinaryReader> handler = null;

			if (_message_handlers.TryGetValue(message_type, out handler))
			{
				sender._last_recv_buffer = net_buffer;
				sender.UpdateKeepAliveTimer();

				try
				{
					handler(sender, reader);
				}
				catch (EndOfStreamException e)
				{
					JLogger.Write("[Exception][DispatchMessages][EndOfStreamException]:" + e.Message);
				}
				catch (ObjectDisposedException e)
				{
					JLogger.Write("[Exception][DispatchMessages][ObjectDisposedException]:" + e.Message);
				}
				catch (IOException e)
				{
					JLogger.Write("[Exception][DispatchMessages][IOException]:" + e.Message);
				}
			}
			else
			{
				JLogger.Write("No handler for message id " + message_type);
			}
		}
        #endregion
        
        #region [����ġ] [Simple] �޽���
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public void DispatchSimpleMessages(NetPeer_base sender, string message_type, NetBuffer net_buffer, BinaryReader reader)
        {
            Action<NetPeer_base, BinaryReader> handler = null;

            if (_simple_message_handlers.TryGetValue(message_type, out handler))
            {
                sender._last_recv_buffer = net_buffer;
                sender.UpdateKeepAliveTimer();

                try
                {
                    handler(sender, reader);
                }
                catch (EndOfStreamException e)
                {
                    JLogger.Write("[Exception][DispatchMessages][EndOfStreamException]:" + e.Message);
                }
                catch (ObjectDisposedException e)
                {
                    JLogger.Write("[Exception][DispatchMessages][ObjectDisposedException]:" + e.Message);
                }
                catch (IOException e)
                {
                    JLogger.Write("[Exception][DispatchMessages][IOException]:" + e.Message);
                }
            }
            else
            {
                JLogger.Write("No handler for message id " + message_type);
            }
        }
        #endregion


        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++led++++++++++++++++++++++++++++++++++++++++++
        // ��ƿ
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [��ƿ] ReadNetData
  //      //------------------------------------------------------------------------------------------------------------------------------------------------------
  //      public static T ReadNetData<T>(BinaryReader reader) where T : JNetData_base, new()
		//{
		//	var netdata = new T();
		//	netdata.Read(reader);
		//	return netdata;
		//}
		#endregion


	}


	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	//
	// NetMessage_dispatcher_default
	//
	//
	//
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	public class NetMessage_dispatcher_default : NetMessage_dispatcher_base
	{
		#region [�ʱ�ȭ]
		//------------------------------------------------------------------------------------------------------------------------------------------------------
		public NetMessage_dispatcher_default(NetPeer_base net_base)
			: base(net_base)
		{ }
		#endregion
	}

}