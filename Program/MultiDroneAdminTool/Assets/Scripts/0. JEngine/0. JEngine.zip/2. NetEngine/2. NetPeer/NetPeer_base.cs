using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Sockets;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using NetEndPoint = System.Net.IPEndPoint;

namespace J2y.Network
{
	#region [Structure] NetPeerReader
	//------------------------------------------------------------------------------------------------------------------------------------------------------
	public struct NetPeerReader
	{
		public NetPeer_base Peer;
		public BinaryReader Reader;
		public static NetPeerReader Create(NetPeer_base peer, BinaryReader reader)
		{
			return new NetPeerReader() { Peer = peer, Reader = reader };
		}
	}
    #endregion


    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //
    // NetPeer_base
    //
    //      1. Network Connections
    //      2. �޽��� �۽�
    //      3. �޽��� ����
    //      4. [���ξ�����] Commands
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    public partial class NetPeer_base : INetMessageHandler
	{
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // ����
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [����] Base
        public long _keep_alive_timer;

        #endregion

        #region [����] Connections
        public NetPeer_base _parent_peer;                     // �������� NetClient�� ��� ���ӵ� �θ𼭹�
		public readonly List<NetPeer_base> m_connections;
		protected readonly Dictionary<NetEndPoint, NetPeer_base> m_connectionLookup;
		#endregion

		#region [����] �޽��� �۽�/����
		public NetSenderChannel_base _sender_channel;
		public NetReceiverChannel_base _recv_channel;
		public NetMessage_dispatcher_base _message_dispatcher;
		public NetBuffer _last_recv_buffer;     // �ʿ��ϳ�??
		#endregion

		#region [����] Commands
		internal readonly NetQueue<Action> _commands_main_thred;
        #endregion


        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // Property
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [Property] Tag/IpAddress

        public Object Tag { get; set; }
		public virtual string _ip_address { get; }
		
        #endregion
        
        #region [Property] [Events] OnConnected/OnDisconnected

        public event Action _event_connected;
        public event Action _event_disconnected;

        #endregion




        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // ���� �Լ�
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [�ʱ�ȭ] ������
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public NetPeer_base()
		{
			_commands_main_thred = new NetQueue<Action>(8);
			m_connectionLookup = new Dictionary<NetEndPoint, NetPeer_base>();
			m_connections = new List<NetPeer_base>();
		}
		#endregion

		#region [������Ʈ] 
		//------------------------------------------------------------------------------------------------------------------------------------------------------
		public virtual void Update()
		{
			if(_recv_channel != null)
				_recv_channel.DispatchMessagess(_message_dispatcher);

			execute_mainThreadCommands();
		}
		#endregion



		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		// 1. ��Ʈ��ũ Connections
		//
		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		
		#region [��Ʈ��ũ] �ʱ�ȭ
		//------------------------------------------------------------------------------------------------------------------------------------------------------
		public virtual void initialize()
		{
			//JTcpNetManager.Add(this);			

			var task_write = _sender_channel.LoopAsyncWrite();
			var task_read = _recv_channel.LoopAsyncRead();			
		}
		#endregion

		#region [��Ʈ��ũ] KeepAliveTimer
		//------------------------------------------------------------------------------------------------------------------------------------------------------
		public void UpdateKeepAliveTimer()
		{
			_keep_alive_timer = JTimer.GetCurrentTick();
		}
		#endregion
		
		#region [��Ʈ��ũ] IsConnected/Disconnect
		//------------------------------------------------------------------------------------------------------------------------------------------------------
		public virtual bool IsConnected() { return false; }
		public virtual void Disconnect() { }
        #endregion

        #region [��Ʈ��ũ] [�̺�Ʈ] OnConnected/OnDisconnected
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public virtual void OnConnected()
		{
			if (_event_connected != null)
				_event_connected();
		}
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public virtual void OnDisconnected()
		{
			if (_event_disconnected != null)
				_event_disconnected();
			
			if (_sender_channel != null)
				_sender_channel.Stop();
			if (_recv_channel != null)
				_recv_channel.Stop();

			_recv_channel = null;
			_sender_channel = null;
		}		
		#endregion

		#region [��Ʈ��ũ] DisconnectAll
		//------------------------------------------------------------------------------------------------------------------------------------------------------
		public void DisconnectAll()
		{
			foreach (var client in m_connections)
				client.Disconnect();
			m_connections.Clear();
		}

        #endregion

        

        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // 2. �޽��� �۽�
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [�۽�] ������ ������
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public virtual eNetSendResult SendMessage(int message_type, params dynamic[] args) { return SendMessage(JNetMessage.Make(message_type, args)); }
        public virtual eNetSendResult SendMessage(int message_type, byte[] data_buffer, int data_size) { return SendMessage(JNetMessage.Make(message_type, data_buffer, data_size)); }
        public virtual eNetSendResult SendMessage(int message_type, JNetData_base netdata, params dynamic[] args) { return SendMessage(JNetMessage.Make(message_type, netdata, args)); }
        public virtual eNetSendResult SendMessage(int message_type, string result, JNetData_base netdata, params dynamic[] args) { return SendMessage(JNetMessage.Make(message_type, netdata, args).SetResult(result)); }
        public virtual eNetSendResult SendMessage(int message_type, Action<BinaryWriter> fun_write) { return SendMessage(JNetMessage.Make(message_type, fun_write)); }
        #endregion

        #region [�۽�] [Simple] ������ ������
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public virtual eNetSendResult SendSimpleMessage(string message_type, params dynamic[] args) { return SendMessage(JNetMessage.MakeSimple(message_type, args)); }
        public virtual eNetSendResult SendSimpleMessage(string message_type, byte[] data_buffer, int data_size) { return SendMessage(JNetMessage.MakeSimple(message_type, data_buffer, data_size)); }
        public virtual eNetSendResult SendSimpleMessage(string message_type, JNetData_base netdata, params dynamic[] args) { return SendMessage(JNetMessage.MakeSimple(message_type, netdata, args)); }
        public virtual eNetSendResult SendSimpleMessage(string message_type, string result, JNetData_base netdata, params dynamic[] args) { return SendMessage(JNetMessage.MakeSimple(message_type, netdata, args).SetResult(result)); }
        public virtual eNetSendResult SendSimpleMessage(string message_type, Action<BinaryWriter> fun_write) { return SendMessage(JNetMessage.MakeSimple(message_type, fun_write)); }
        #endregion


        #region [�۽�] JNetMessage
        //------------------------------------------------------------------------------------------------------------------------------------------------------		
        public virtual eNetSendResult SendMessage(JNetMessage message)
        {
            return _sender_channel.SendMessage(message);
        }
        #endregion

        #region [�۽�] Broadcast
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        // ����: �޽��� ��Ȱ�� �ʿ�(NetBuffer.MemoryStream�� ��� ��Ƽ�����忡�� ���ư��� ������ �ܼ� ����Ʈ�� �����ؼ��� �ȵ� ��)
        //
        public virtual void Broadcast(JNetMessage message, NetPeer_base except = null)
		{
            foreach (var c in m_connections)
            {
                if (c != except)
                    c.SendMessage(message);
            }
		}
        #endregion

        #region [�۽�] ���̳ʸ� ��뷮 ������(����) ���� (10 MB ���ϴ� �Ϲ� �޽����� ����)
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public long SendFile(string filepath)
        {
            return _sender_channel.SendFile(filepath);
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public long SendBigData(byte[] send_data)
        {
            return _sender_channel.SendBigData(send_data);
        }
        #endregion



        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // 3. �޽��� ����
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [����] �޽��� �ڵ鷯 ���
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public virtual void RegisterMessageHandler(int id, Action<NetPeer_base, BinaryReader> handler, bool overwrite = false)
        {
            if (null == _message_dispatcher)
                return;
            _message_dispatcher.RegisterMessageHandler(id, handler, overwrite);
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public virtual void UnregisterMessageHandler(int id)
        {
            if (null == _message_dispatcher)
                return;
            _message_dispatcher.UnregisterMessageHandler(id);
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public virtual void RegisterSimpleMessageHandler(string id, Action<NetPeer_base, BinaryReader> handler, bool overwrite = false)
        {
            if (null == _message_dispatcher)
                return;
            _message_dispatcher.RegisterSimpleMessageHandler(id, handler, overwrite);
        }
        #endregion
        
        #region [����] [�񵿱�] aysnc, await
        //---------------------------------------------------------------------------------------------------------------------------------
        public async Task<NetPeerReader> WaitMessageAsync(string message_type, bool overwrite = true)
		{			
			var tcs = new TaskCompletionSource<NetPeerReader>();
            RegisterSimpleMessageHandler(message_type, (p, r) =>
			{
				tcs.SetResult(NetPeerReader.Create(p,r));
			}, overwrite);
			var result = await tcs.Task;
			return result;
		}
        #endregion

        #region [����] ���̳ʸ� ��뷮 ������(����)
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public virtual bool OnRecv_FileTransfer(BinaryReader reader)
        {
            return _recv_channel.OnRecv_FileTransfer(reader);
        }
        public byte[] GetFileTransferData(long file_guid, bool removeFromRepository = true)
        {
            return _recv_channel.GetFileTransferData(file_guid, removeFromRepository);
        }
        public bool SaveFileTransferData(long file_guid, string filepath, bool removeFromRepository = true)
        {
            return _recv_channel.SaveFileTransferData(file_guid, filepath, removeFromRepository);
        }
        #endregion

        #region [MessageDispatcher] Set
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public void SetMessageDispatcher(NetMessage_dispatcher_base dispatcher)
        {
            _message_dispatcher = dispatcher;
        }
        #endregion



        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // 4. [���ξ�����] Commands
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [���ξ�����] [Commands] �߰�
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public void AddMainThreadCommand(Action fun)
		{
			_commands_main_thred.Enqueue(fun);
		}
		#endregion

		#region [���ξ�����] [Commands] ����
		//------------------------------------------------------------------------------------------------------------------------------------------------------
		protected void execute_mainThreadCommands()
		{
			while(_commands_main_thred.Count > 0)
			{
				Action command;
				if(_commands_main_thred.TryDequeue(out command))
					command();
			}			
		}
		#endregion


        

       

		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		// ���
		//
		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


		#region [���] [NetStream] [WorkThread] RequestAsyncWorks
		////------------------------------------------------------------------------------------------------------------------------------------------------------
		//public void RequestAsyncWorks()
		//{
		//	//Task.Run(async () =>
		//	//{
		//	//	NetBase.AddThreadID(Thread.CurrentThread.ManagedThreadId);												
		//	//	await _sender_channel.RequestWriteAsync();				
		//	//});

		//	//Task.Run(async () =>
		//	//{
		//	//	NetBase.AddThreadID(Thread.CurrentThread.ManagedThreadId);
		//	//	await _recv_channel.RequestReadAsync();
		//	//});

		//	//var task_write = _sender_channel.RequestWriteAsync();
		//	//var task_read = _recv_channel.RequestReadAsync();

		//}
		#endregion
	}

}
