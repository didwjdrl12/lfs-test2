using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
#if !OLD_DOT_NET
using System.Threading.Tasks;
#endif



namespace J2y.Network
{
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	//
	// NetTcpClient
	//
	//
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	public class NetTcpClient : NetTcpPeer_base, IDisposable
	{
		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		// ����
		//
		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


		#region ����

		public TcpClient _net_client;
		
		
		#endregion


		#region [Property]

		public override string _ip_address
		{
			get { return _net_client.Client.RemoteEndPoint.ToString(); }
		}
		public int _remote_port
		{
			get; set;
		}

		#endregion


		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		// ���� �Լ�
		//
		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

		#region [�ʱ�ȭ] ������
		//------------------------------------------------------------------------------------------------------------------------------------------------------
		public NetTcpClient()
		{ }
		//------------------------------------------------------------------------------------------------------------------------------------------------------
		public NetTcpClient(TcpClient net_client)
			: this()
		{
			initialize(net_client);
		}
		//------------------------------------------------------------------------------------------------------------------------------------------------------
		public NetTcpClient(string server_ip, int port)
			: this()
		{
			Connect(server_ip, port);
		}
		#endregion

		#region [�ʱ�ȭ] initialize
		//------------------------------------------------------------------------------------------------------------------------------------------------------
		public virtual void initialize(TcpClient net_client)
		{
			_net_client = net_client;
			_net_stream = net_client.GetStream();

			initialize(_net_stream);

			//var end_point = _net_client.Client.RemoteEndPoint as IPEndPoint;
		}
        #endregion


        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // [��Ʈ��ũ]
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [��Ʈ��ũ] ����
        static int cnt = 0;
		//------------------------------------------------------------------------------------------------------------------------------------------------------
		public virtual bool Connect(string server_ip, int port, Action<int> fun_connected = null)
		{
			if(IsConnected())
			{
				if (fun_connected != null)
					fun_connected(1);
				return true;
			}

			try
			{
				var net_client = new TcpClient(server_ip, port);
				if (null == net_client)
					return false;
				if(null == _message_dispatcher)
					_message_dispatcher = new NetMessage_dispatcher_default(this);
				initialize(net_client);
				OnConnected();
				_remote_port = port;
				if (fun_connected != null)
					fun_connected(1);
			}
			catch (SocketException e)
			{
				JLogger.WriteFormat(@"[TCP] Server Connect Fail!!! " + e.Message);
                
                //if(++cnt < 5)
                
                //Connect(server_ip, port, fun_connected);

				return false;
			}

			return true;
		}
		#endregion

		#region [��Ʈ��ũ] ����
		//------------------------------------------------------------------------------------------------------------------------------------------------------
		public void Dispose()
		{
			Disconnect();
		}

		//------------------------------------------------------------------------------------------------------------------------------------------------------
		public override void Disconnect()
		{
			var conn = IsConnected();
			if (!conn)
				return;
			
			if (conn)
				OnDisconnected();

			var ip_address = _ip_address;
			try
			{
				_net_client.Client.Disconnect(false);
				_net_stream.Close();
				_net_client.Close();
			}
			catch(SocketException e)
			{
				JLogger.WriteFormat(@"[SocketException] [Disconnect]({0} {1}).", ip_address, e.Message);
			}
			//var conn2 = IsConnected();
			//JLogger.WriteFormat(@"Disconnect Clients({0} {1}).", ip_address, conn2);

		}
		#endregion

		#region [��Ʈ��ũ] [�̺�Ʈ] OnConnected/OnDisconnected
		//------------------------------------------------------------------------------------------------------------------------------------------------------
		public override void OnConnected()
		{			
			base.OnConnected();
		}
		//------------------------------------------------------------------------------------------------------------------------------------------------------
		public override void OnDisconnected()
		{			
			var server = _parent_peer as NetTcpServer;
			if (server != null)
			{
				server.OnClientDisconnected(this);
				server.m_connections.Remove(this);
			}
			base.OnDisconnected();
		}
		#endregion

		#region [��Ʈ��ũ] IsConnected
		//------------------------------------------------------------------------------------------------------------------------------------------------------
		public override bool IsConnected()
		{
			return (_net_client != null) && _net_client.Connected;

			#region [���]
			//if (_net_client.Connected)
			//{
			//	return IsConnected(_net_client.Client);
			//	//if ((_net_client.Client.Poll(0, SelectMode.SelectWrite)) && (!_net_client.Client.Poll(0, SelectMode.SelectError)))
			//	//{
			//	//	byte[] buffer = new byte[1];
			//	//	if (_net_client.Client.Receive(buffer, SocketFlags.Peek) == 0)
			//	//	{
			//	//		return false;
			//	//	}
			//	//	else
			//	//	{
			//	//		return true;
			//	//	}
			//	//}
			//	//else
			//	//{
			//	//	return false;
			//	//}
			//}
			//else
			//{
			//	return false;
			//}
			#endregion
		}
		public static bool IsConnected(Socket socket)
		{
			try
			{
				return !(socket.Poll(1, SelectMode.SelectRead) && socket.Available == 0);
			}
			catch (SocketException) { return false; }
		}
		#endregion






		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		// ��ƿ
		//
		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

		#region [��ƿ] ��Ŷ ��ȿ�� �˻�
		//------------------------------------------------------------------------------------------------------------------------------------------------------
		public virtual bool ValidPacket(byte command)
		{
			return true;
		}
		#endregion

		#region [��ƿ] Check Sum ���
		//------------------------------------------------------------------------------------------------------------------------------------------------------
		public static byte MakeChecksum(byte[] send_buf)
		{
			byte checkSum = 0;
			foreach (var ch in send_buf)
				checkSum += (byte)ch;

			return checkSum;
		}
		#endregion



		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		// �۾���...
		//
		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++






	}

}

