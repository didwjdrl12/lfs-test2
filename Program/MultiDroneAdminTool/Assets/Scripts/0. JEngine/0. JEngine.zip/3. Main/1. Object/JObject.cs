using J2y.Network;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using UnityEngine;


namespace J2y
{
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //
    // JObject : ��� �����Ǵ� ��ü�� �θ�
    //      Ŭ���̾�Ʈ�� MonoBehaviour�� ���
    //
    //      1. �����ֱ�
    //		    todo: Awake, Start, Update, OnDestroy �� ���÷����� �̿��Ͽ� �ʿ��� ��츸 ȣ��
    //      2. ObjectPool (GUID)
    //      3. RPC
    //      4. Serialize
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#if NET_SERVER
    public class JObject // : IDisposable
#else
    public class JObject : MonoBehaviour
#endif
    {
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // ����
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        
        #region [����] 1. �����ֱ�
#if NET_SERVER
        private bool _enabled;
        private bool _first_update = true;
        private bool _destroyed;
#endif
        #endregion

        #region [����] 2. Base
        public GameObject _gameObject;
        #endregion

        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // Property
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


        #region [Property] JObject
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        protected string _log_tag_internal;
        public virtual string _log_tag
        {
            get
            {
                if (null == _log_tag_internal)
                    _log_tag_internal = GetType().Name;
                return _log_tag_internal;
            }
            set { _log_tag_internal = value; }
        }
        #endregion

        #region [Property] GUID
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public virtual long _guid { get; set; } = JUtil.CreateUniqueId();
		#endregion

		#region [Property] NetRole
		//------------------------------------------------------------------------------------------------------------------------------------------------------
		public virtual eNetRole _net_role { get; set; }
        public virtual eNetRole _net_remote_role { get; set; }
        #endregion




        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // 1. �����ֱ�
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [�����ֱ�] Awake/Start/OnDestroy/Update
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public virtual void Awake() { }
        public virtual void Start() { }
        public virtual void OnDestroy() { }
        public virtual void Update() { }
        #endregion

        #region [����] [�����ֱ�] Internal
#if NET_SERVER
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public virtual void AwakeInternal()
        {
            Awake();
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public virtual void UpdateInternal()
        {
            if (_first_update)
            {
                Start();
                _first_update = false;
            }            
            Update();
        }
        public virtual void DestroyInternal()
        {
            if (_destroyed)
                return;
            Enabled = false;
            OnDestroy();
            _destroyed = true;
        }
#endif
        #endregion

        #region [����] [�����ֱ�] Enabled
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public bool Enabled
        {
#if NET_SERVER
            get { return _enabled; }
            set
            {
                if (_enabled == value)
                    return;
                _enabled = value;
                if (_enabled)
                    OnEnable();
                else
                    OnDisable();
            }
#else
            get { return enabled; }
            set { enabled = value; }
#endif
        }

        public virtual void OnEnable() { }
        public virtual void OnDisable() { }

        #endregion

        #region [���] [����] �Ҹ�
        //   //------------------------------------------------------------------------------------------------------------------------------------------------------
        //   ~JObject()
        //{
        //       // todo: ���� �ʿ�(�Ҹ��ڿ����� �����Լ� ȣ���� �ȵ�.. �̹� ���� ���� �߿� �Ǵٸ� ������ �߻�..)
        //       if (!_destroyed)
        //           DestroyObject(this);
        //       Dispose(false);
        //   }
        #endregion


        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // 2. ObjectPool
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [ObjectPool] Create
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static T CreateObject<T>() where T : JObject
        {
            return JObjectManager.Create<T>();
        }
        #endregion

        #region [ObjectPool] Destroy
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void DestroyObject(JObject obj)
        {
            JObjectManager.Destroy(obj);
        }
        #endregion


        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // 3. RPC
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [RPC] ��û
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public eRpcResult RPC(eReplicationType rep_type, string fun_name, params dynamic[] args)
        {
			if ((rep_type == eReplicationType.Client) || (_net_role >= eNetRole.AutonomousProxy))
			{
				JRPCMediator.NetSendRPC(rep_type, this, fun_name, args);
				return eRpcResult.Succeed;
			}

			return eRpcResult.NoAuthority;
		}
        #endregion

        #region [Network] [����] �ش� ��ü(���� �Ǵ� ����)�� �޽��� ����
        public virtual eNetSendResult NetSendMessage(JNetMessage message) { return eNetSendResult.UnknownError; }
        #endregion

        #region [Network] [����] �ش� ��ü(����, �ʵ�, ����) �ֺ����� �޽��� ����
        public virtual void NetBroadcast(JNetMessage message, JObject except = null) { }
        #endregion



        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // 4. Serialize
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [Serialize] 
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public virtual void Serialize(BinaryWriter writer)
        {
            
        }
        #endregion

        #region [Deserialize] 
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public virtual void Deserialize(BinaryReader reader)
        {

        }
        #endregion

        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // ���
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [���] GUID
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        //internal GUID m_GUID;
        //public GUID guid { get { return m_GUID; } }
        //internal long m_LocalIdentifierInFile;
        //public long localIdentifierInFile { get { return m_LocalIdentifierInFile; } }

        //[NativeName("fileType")]
        //internal FileType m_FileType;
        //public FileType fileType { get { return m_FileType; } }

        //internal string m_FilePath;
        //public string filePath { get { return m_FilePath; } }

        //public override string ToString()
        //{
        //	return UnityString.Format("{{guid: {0}, fileID: {1}, type: {2}, path: {3}}}", m_GUID, m_LocalIdentifierInFile, m_FileType, m_FilePath);
        //}


        //public override int GetHashCode()
        //{
        //	unchecked
        //	{
        //		var hashCode = m_GUID.GetHashCode();
        //		hashCode = (hashCode * 397) ^ m_LocalIdentifierInFile.GetHashCode();
        //		hashCode = (hashCode * 397) ^ (int)m_FileType;
        //		if (!string.IsNullOrEmpty(m_FilePath))
        //			hashCode = (hashCode * 397) ^ m_FilePath.GetHashCode();
        //		return hashCode;
        //	}
        //}
        #endregion





    }
}
