using System;
using System.Collections;
using System.Collections.Generic;
#if !NET_SERVER
using UnityEngine;
#endif

namespace J2y
{
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //
    // JObjectManager
    //		
    //
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    public class JObjectManager
    {
        public static JObjectManager Instance = new JObjectManager();

        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // ����
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [����] Object Pool
        private Dictionary<Type, Stack<JObject>> m_GenericPool = new Dictionary<Type, Stack<JObject>>();
        #endregion

        #region [����] JObjects
        private static IDictionary<long, JObject> _objects = new Dictionary<long, JObject>();
        #endregion


        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // ObjectPool
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [ObjectPool] Get
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static T Get<T>() where T : JObject
        {
            return Instance.GetInternal<T>();
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        private T GetInternal<T>() where T : JObject
        {
            Stack<JObject> pooledObjects;
            if (m_GenericPool.TryGetValue(typeof(T), out pooledObjects))
            {
                if (pooledObjects.Count > 0)
                {
                    return pooledObjects.Pop() as T;
                }
            }
            return Create<T>();
        }
        #endregion

        #region [ObjectPool] Return
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void Return<T>(T obj) where T : JObject
        {
            Instance.ReturnInternal(obj);
        }

        //------------------------------------------------------------------------------------------------------------------------------------------------------
        private void ReturnInternal(JObject obj)
        {
            Stack<JObject> pooledObjects;
            if (m_GenericPool.TryGetValue(obj.GetType(), out pooledObjects))
            {
                pooledObjects.Push(obj);
            }
            else
            {
                pooledObjects = new Stack<JObject>();
                pooledObjects.Push(obj);
                m_GenericPool.Add(obj.GetType(), pooledObjects);
            }
        }
        #endregion



        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // Create/Destroy
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [ObjectPool] Create
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static T Create<T>(Action<JObject> pre_init = null) where T : JObject
        {
#if NET_SERVER
            //var obj = Get<T>(); // ObjectPool�� ����ϸ� ���� �ʱ�ȭ�� ������ �ȵ� �� �����Ƿ� ���� ����(��� ���� �ʿ�)
            var obj = Activator.CreateInstance<T>();
            pre_init?.Invoke(obj);
            Add(obj);
            obj.AwakeInternal();
            obj.Enabled = true;
            // todo: Update �Լ��� �ִ� ��츸 �߰�
            // todo: ������..
            //JScheduler.AddUpdatable(obj.UpdateInternal);

#else
            var obj = new GameObject(typeof(T).Name).AddComponent<T>();
            obj._gameObject = obj.gameObject;
#endif
            return obj;
        }
        #endregion

        #region [ObjectPool] Destroy
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void Destroy<T>(T obj) where T : JObject
        {
            if (null == obj)
                return;
#if NET_SERVER
            // todo: ������..
            // JScheduler.CancelUpdatable(obj.UpdateInternal);
            obj.DestroyInternal();
#else
            GameObject.Destroy(obj);
#endif

            Remove(obj);
        }
        #endregion






        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // JObject
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [JObject] �߰�/����	
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static bool Add(JObject obj)
        {
            if (Exist(obj._guid))
                return false;
            _objects[obj._guid] = obj;
            return true;
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static bool Remove(long guid)
        {
            var obj = Find(guid);
            if (obj != null)
            {
                _objects.Remove(guid);
                return true;
            }
            return false;
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static bool Remove(JObject obj)
        {
            return Remove(obj._guid);
        }

        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void Clear()
        {
            _objects.Clear();
        }
        #endregion

        #region [JObject] ã��
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static IEnumerable<JObject> ObjectList()
        {
            return _objects.Values;
        }

        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static JObject Find(long guid)
        {
            if (Exist(guid))
                return _objects[guid];
            return null;
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static bool Exist(long guid)
        {
            return _objects.ContainsKey(guid);
        }
        #endregion



    }

}
