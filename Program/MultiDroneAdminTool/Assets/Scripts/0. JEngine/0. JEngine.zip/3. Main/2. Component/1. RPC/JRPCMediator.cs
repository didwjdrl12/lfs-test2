using J2y.Network;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using UnityEngine;



namespace J2y
{

    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //
    // JRPCMediator
    //      
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    public static class JRPCMediator
    {
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // ���, Static
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [���] 
        #endregion


        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // [RPC] [NetMessage]
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


        #region [RPC] [NetMessage] Make        
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static JNetMessage MakeMessage(eReplicationType rpc_type, JObject caller, string fun_name, params dynamic[] args)
        {
            return MakeMessage(rpc_type, caller, (writer) =>
            {
                writer.Write((int)eRpcType.MethodCall);
                writer.Write(fun_name);
                JSerialization.Serialize(writer, args);
            });
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static JNetMessage MakeMessage(eReplicationType rep_type, JObject caller, Action<BinaryWriter> fun_write)
        {
            var net_message = JNetMessage.Make(JNetMessageProtocol.RPC, (writer) =>
            {
                writer.Write((int)rep_type);
                writer.Write(caller._guid);
                fun_write(writer);
            });
            return net_message;
        }
        #endregion



        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // RPC
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [RPC] ��û (��Ʈ��ũ ����)
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void NetSendRPC(eReplicationType rpc_type, JObject caller, string fun_name, params dynamic[] args)
        {
            JEngineRoot.Instance.NetSendRPC(rpc_type, caller, fun_name, args);
        }
        #endregion

        #region [RPC] ��û ���� (��Ʈ��ũ ����)        
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void OnNetRecvRPC(NetPeer_base sender, BinaryReader reader)
        {
            //-------------------------------------------------------------------------------------
            // 1. �⺻ RPC �Ӽ�
            //
            var rep_type = (eReplicationType)reader.ReadInt32();
            var obj_guid = reader.ReadInt64();
            var rpc_type = (eRpcType)reader.ReadInt32();
            var obj = JObjectManager.Find(obj_guid);            
            if (null == obj)
                return;

            //-------------------------------------------------------------------------------------
            // 2. RPC �Լ� ȣ��
            //
            if (rpc_type == eRpcType.MethodCall)
            {
                //-------------------------------------------------------------------------------------
                // 2.1. RPC �Լ� ã��, �Ķ���� ����
                //
                var fun_name = reader.ReadString();
                var method = JReflection.FindMethod(obj.GetType(), fun_name);
                if (null == method)
                    return;

                var args = JSerialization.Deserialize(reader) as object[];

                //-------------------------------------------------------------------------------------
                // 2.2. RPC ȣ��
                //
                OnNetRecvRPC(rep_type, obj_guid, fun_name, args);
            }
            //-------------------------------------------------------------------------------------
            // 3. ���� ����
            //
            else if (rpc_type == eRpcType.SpawnActor)
            {                
                var actor = JActor.New();
                actor.Deserialize(reader);                
            }
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void OnNetRecvRPC(eReplicationType rep_type, long obj_guid, string fun_name, params object[] args)
        {
            var com = JObjectManager.Find(obj_guid);
            if (null == com)
                return;
            MethodInvoke(com, fun_name, args);
        }        
        #endregion

        #region [RPC] �Լ� ȣ��
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void MethodInvoke(JObject obj, string fun_name, params object[] args)
        {
            if (null == obj)
                return;

            var method = JReflection.FindMethod(obj.GetType(), fun_name);
            if (null == method)
                return;
            method.Invoke(obj, args);
        }
        #endregion


        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // ���
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [���] [RPC] [��ƿ] �Ķ���� ����
        ////------------------------------------------------------------------------------------------------------------------------------------------------------
        //public static object ReadArgument(Type type, BinaryReader reader)
        //{
        //    object value;

        //    var primitive_type = JReplication.HasReadMethod(type);
        //    if (primitive_type)
        //    {
        //        JReplication.Read(reader, type, out value);                
        //    }
        //    // NetData, List, Dictionary
        //    else
        //    {
        //        //var is_netdata = type.IsClass && typeof(JNetData_base).IsSubclassOf(type);

        //        var netdata = Activator.CreateInstance(type) as JNetData_base;
        //        value = JSerialization.Deserialize(reader);
        //    }

        //    return value;            
        //}
        #endregion

        #region [���] [RPC] [��ƿ] �Ķ���� Serialization
        ////------------------------------------------------------------------------------------------------------------------------------------------------------
        //public static object WriteArgument(object value, BinaryWriter writer)
        //{
        //    var type = value.GetType();
        //    var primitive_type = JReplication.HasWriteMethod(type);

        //    if (primitive_type)
        //    {
        //        JReplication.Write(writer, type, value);
        //    }
        //    // NetData, List, Dictionary
        //    else
        //    {
        //        //var is_netdata = type.IsClass && typeof(JNetData_base).IsSubclassOf(type);

        //        var netdata = Activator.CreateInstance(type) as JNetData_base;
        //        JSerialization.Serialize(writer, value);
        //    }

        //    return value;
        //}
        #endregion






    }


}
