using J2y.Network;
using System;
using System.Collections.Generic;
using System.IO;

namespace J2y
{
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //
    // JEngineRoot
    //      ��ü ������ �����ϴ� Ŭ����, �� �ý����� �� Ŭ������ ��� �޾� ������ ��ɵ��� �����Ѵ�.
    //
    //      1. RPC (Send, Recv)
    //      2. Spawn Actor
    //      3. Create Component
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    public class JEngineRoot : JObject
    {
        public static JEngineRoot Instance;

        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // ����
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


        #region [����] 0. �⺻ ����
        #endregion


        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // Property
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [Property] [Actor] NetRole
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public virtual bool IsServer
        {
            get { return (_net_role == eNetRole.Authority); }
        }
        public virtual bool IsClient
        {
            get { return !IsServer; }
        }
        #endregion



        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // ���� �Լ�
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [�ʱ�ȭ] Awake
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public override void Awake()
        {
            Instance = this;

        }
        #endregion


        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // 1. RPC
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [RPC] ��û
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public virtual void NetSendRPC(eReplicationType rpc_type, JObject caller, string fun_name, params dynamic[] args)
        {
            switch(rpc_type)
            {
                case eReplicationType.Client: break;
                case eReplicationType.Server: break;
                case eReplicationType.Multicast: break;
            }
        }        
        #endregion
        

        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // 2. Actor
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                
        #region [�ڡڡڡ�] [Actor] Spawn
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public virtual JActor RPCSpawnActor(eReplicationType rep_type, JObject caller, long dataInfoId)
        {
            JActor dest_actor = null;

            switch (rep_type)
            {
                case eReplicationType.Client:
                    {
                        //--------------------------------------------------------------------
                        // [S->C] Ŭ�� ���� ��û
                        if (_net_role == eNetRole.Authority)
                        {                            
                            // 1. ���� ����
                            dest_actor = SpawnActor(dataInfoId);

                            // 2. Ŭ�� ���� �˸�
                            var net_message = JRPCMediator.MakeMessage(rep_type, caller, (writer) =>
                            {
                                writer.Write((int)eRpcType.SpawnActor);
                                dest_actor.Serialize(writer);
                            });
                            caller.NetSendMessage(net_message);
                        }
                        //--------------------------------------------------------------------
                        // [C->C] ��� ����
                        else
                        {
                            dest_actor = SpawnActor(dataInfoId);
                        }
                    }
                    break;

                case eReplicationType.Server:
                    {
                        //--------------------------------------------------------------------
                        // [S->S] �������� ����
                        if (_net_role == eNetRole.Authority)
                        {
                            dest_actor = SpawnActor(dataInfoId);
                        }
                        //--------------------------------------------------------------------
                        // [C->S] ������ ���� ��û
                        else
                        {
                            NetSendRPC(rep_type, this, "OnRPCSpawnActor", caller._guid, dataInfoId);
                        }
                    }
                    break;

                case eReplicationType.Multicast:
                    {
                        //--------------------------------------------------------------------
                        // [S->Noti] ������ ���� �� 
                        //
                        if (_net_role == eNetRole.Authority)
                        {
                            // 1. ���� ����
                            dest_actor = SpawnActor(dataInfoId);

                            // 2. Ŭ�� ���� �˸�
                            var net_message = JRPCMediator.MakeMessage(rep_type, caller, (writer) =>
                            {
                                writer.Write((int)eRpcType.SpawnActor);
                                dest_actor.Serialize(writer);
                            });
                            caller.NetBroadcast(net_message);
                        }
                        //--------------------------------------------------------------------
                        // [C->S] ������ ���� ��û
                        else
                        {
                            NetSendRPC(rep_type, this, "OnRPCSpawnActor", caller._guid, dataInfoId);
                        }
                    }
                    break;
            }

            //if (_net_role == eNetRole.Authority)
            //{
            //    // 1. ���������� ���� �� ����
            //    var actor = SpawnActor(dataInfoId);
            //    RPCSpawnActor(rpc_type, caller, actor);
            //}
            //else
            //{
            //    // 2. Ŭ�󿡼��� ������ ��û
            //    RPC(rpc_type, "RPCSpawnActor", dataInfoId);
            //}

            return dest_actor;
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public virtual void OnRPCSpawnActor(eReplicationType rep_type, long caller_guid, long dataInfoId)
        {
            var caller = JObjectManager.Find(caller_guid);
            if (null == caller)
                return;
            RPCSpawnActor(rep_type, caller, dataInfoId);
        }
        #endregion

        #region [������] [Actor] Spawn (�ַ� �������� ȣ��)
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public virtual void RPCSpawnActor(eReplicationType rep_type, JObject caller, JActor src_actor)
        {

        }
        #endregion
        
        #region [Actor] [Abstarct] Spawn 
        //------------------------------------------------------------------------------------------------------------------------------------------------------        
        public virtual JActor SpawnActor(long dataInfoId)
        {
            // todo: �ڽ� Ŭ�������� Actor �� Component ���� 
            return JObjectManager.Create<JActor>();
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public virtual JActor SpawnActor(JActor src_actor)
        {
            // todo: �ڽ� Ŭ�������� Actor �� Component ���� 
            return JObjectManager.Create<JActor>();
        }
        #endregion


        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // 3. Component
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [Component] Create<T>
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static T CreateComponent<T>(JActor parent_actor) where T : JComponent
        {
            return null;
        }
        #endregion

        #region [Component] Create(type_name)
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static JComponent CreateComponent(JActor parent_actor, string type_name)
        {
            return null;
        }
        #endregion
    }
}
