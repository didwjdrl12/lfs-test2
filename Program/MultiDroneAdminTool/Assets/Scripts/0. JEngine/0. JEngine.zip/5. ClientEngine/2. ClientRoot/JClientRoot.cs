﻿using UnityEngine;
using System;
using System.Collections.Generic;
using J2y.Network;
using System.IO;

namespace J2y
{
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //
    // MdsServerRoot_base
    //
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    public class JClientRoot : JEngineRoot
    {
        public new static JClientRoot Instance;

        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // 변수
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region 변수

        public NetTcpClient _tcp_client;

        #endregion



        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // 초기화
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [초기화] Awake
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public override void Awake()
        {
            base.Awake();
            Instance = this;
        }
        #endregion



        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // RPC
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [RPC] 요청
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public override void NetSendRPC(eReplicationType rpc_type, JObject caller, string fun_name, params dynamic[] args)
        {
            var net_message = JRPCMediator.MakeMessage(rpc_type, caller, fun_name, args);

            switch (rpc_type)
            {
                case eReplicationType.Client:
                    {
                        if (null == caller)
                            return;
                        JRPCMediator.MethodInvoke(caller, fun_name, args);                        
                    }
                    return;
                case eReplicationType.Server:
                    {
                        NetSendMessage(net_message);
                    }
                    return;
                case eReplicationType.Multicast:
                    {
                        // todo: 서버에 전파를 요청
                        NetBroadcast(net_message);
                    }
                    return;
            }

            base.NetSendRPC(rpc_type, caller, fun_name, args);
        }
        #endregion



        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // [네트워크] [송신]
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [네트워크] [송신] 데이터 보내기
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public override eNetSendResult NetSendMessage(JNetMessage message) { return _tcp_client.SendMessage(message); }

        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public virtual eNetSendResult NetSendMessage(int message_type, params dynamic[] args) { return NetSendMessage(JNetMessage.Make(message_type, args)); }
        public virtual eNetSendResult NetSendMessage(int message_type, byte[] data_buffer, int data_size, bool immediate = true) { return NetSendMessage(JNetMessage.Make(message_type, data_buffer, data_size, immediate)); }
        public virtual eNetSendResult NetSendMessage(int message_type, JNetData_base netdata, bool immediate = true, params dynamic[] args) { return NetSendMessage(JNetMessage.Make(message_type, netdata, immediate, args)); }
        public virtual eNetSendResult NetSendMessage(int message_type, string result, JNetData_base netdata, bool immediate = true, params dynamic[] args) { return NetSendMessage(JNetMessage.Make(message_type, result, netdata, immediate, args)); }
        public virtual eNetSendResult NetSendMessage(int message_type, Action<BinaryWriter> fun_write, bool immediate = true) { return NetSendMessage(JNetMessage.Make(message_type, fun_write, immediate)); }
        #endregion

        #region [네트워크] [송신] [Simple] 데이터 보내기
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public virtual eNetSendResult NetSendSimpleMessage(string message_type, params dynamic[] args) { return NetSendMessage(JNetMessage.MakeSimple(message_type, args)); }
        public virtual eNetSendResult NetSendSimpleMessage(string message_type, byte[] data_buffer, int data_size, bool immediate = true) { return NetSendMessage(JNetMessage.MakeSimple(message_type, data_buffer, data_size, immediate)); }
        public virtual eNetSendResult NetSendSimpleMessage(string message_type, JNetData_base netdata, bool immediate = true, params dynamic[] args) { return NetSendMessage(JNetMessage.MakeSimple(message_type, netdata, immediate, args)); }
        public virtual eNetSendResult NetSendSimpleMessage(string message_type, string result, JNetData_base netdata, bool immediate = true, params dynamic[] args) { return NetSendMessage(JNetMessage.MakeSimple(message_type, result, netdata, immediate, args)); }
        public virtual eNetSendResult NetSendSimpleMessage(string message_type, Action<BinaryWriter> fun_write, bool immediate = true) { return NetSendMessage(JNetMessage.MakeSimple(message_type, fun_write, immediate)); }
        #endregion

        #region [네트워크] [송신] Broadcast
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public override void NetBroadcast(JNetMessage message, JObject except = null)
        {
            _tcp_client.SendMessage(message);
        }
        #endregion
    }

}
