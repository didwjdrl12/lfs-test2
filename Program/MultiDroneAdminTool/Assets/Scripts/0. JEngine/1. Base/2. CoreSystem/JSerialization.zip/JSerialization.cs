using System.IO;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using UnityEngine;
using System.Reflection;


namespace J2y
{
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //
    // SerializationSurrogate
    //
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #region [SerializationSurrogate] Vector3
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    sealed class Vector3SerializationSurrogate : ISerializationSurrogate
    {
        #region [Serialize] GetObjectData
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public void GetObjectData(System.Object obj, SerializationInfo info, StreamingContext context)
        {         
            var v3 = (Vector3) obj;
            info.AddValue("x", v3.x);
            info.AddValue("y", v3.y);
            info.AddValue("z", v3.z);
            //Debug.Log(v3);
        }
        #endregion

        #region [Deserialize] SetObjectData
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public System.Object SetObjectData(System.Object obj, SerializationInfo info, StreamingContext context, ISurrogateSelector selector)
        {         
            var v3 = (Vector3) obj;
            v3.x = (float)info.GetValue("x", typeof(float));
            v3.y = (float)info.GetValue("y", typeof(float));
            v3.z = (float)info.GetValue("z", typeof(float));
            obj = v3;
            return obj;   // Formatters ignore this return value //Seems to have been fixed!
        }
        #endregion

    }
    #endregion

    #region [SerializationSurrogate] Quaternion
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    sealed class QuaternionSerializationSurrogate : ISerializationSurrogate
    {
        #region [Serialize] GetObjectData
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public void GetObjectData(System.Object obj, SerializationInfo info, StreamingContext context)
        {
            var q = (Quaternion)obj;
            info.AddValue("x", q.x);
            info.AddValue("y", q.y);
            info.AddValue("z", q.z);
            info.AddValue("w", q.w);
            //Debug.Log(v3);
        }
        #endregion

        #region [Deserialize] SetObjectData
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public System.Object SetObjectData(System.Object obj, SerializationInfo info, StreamingContext context, ISurrogateSelector selector)
        {
            var q = (Quaternion)obj;
            q.x = (float)info.GetValue("x", typeof(float));
            q.y = (float)info.GetValue("y", typeof(float));
            q.z = (float)info.GetValue("z", typeof(float));
            q.w = (float)info.GetValue("w", typeof(float));
            obj = q;
            return obj;   // Formatters ignore this return value //Seems to have been fixed!
        }
        #endregion

    }
    #endregion



    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //
    // JSerialization
    //
    //
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    public static class JSerialization
    {

        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        //  [BinaryFormatter]
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        private static BinaryFormatter s_binary_formatter;

        #region [BinaryFormatter] ���� (+ SerializationSurrogate)
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static BinaryFormatter MakeBinaryFormatter()
        {
            var bf = new BinaryFormatter();

            var ss = new SurrogateSelector();
            ss.AddSurrogate(typeof(Vector3), new StreamingContext(StreamingContextStates.All), new Vector3SerializationSurrogate());
            ss.AddSurrogate(typeof(Quaternion), new StreamingContext(StreamingContextStates.All), new QuaternionSerializationSurrogate());


            bf.SurrogateSelector = ss;
            return bf;
        }
        #endregion

        #region [BinaryFormatter] GET
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static BinaryFormatter GetBinaryFormatter()
        {
            if (null == s_binary_formatter)
                s_binary_formatter = MakeBinaryFormatter();

            return s_binary_formatter;
        }
        #endregion


        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        //  [Serialization]
        //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        #region [Serialize] Stream/BinaryWriter
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void Serialize(Stream serializationStream, object graph)
        {
            GetBinaryFormatter().Serialize(serializationStream, graph);
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static void Serialize(BinaryWriter writer, object graph)
        {
            GetBinaryFormatter().Serialize(writer.BaseStream, graph);
           
        }
        #endregion


        #region [Deserialize] Stream/BinaryReader
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static object Deserialize(Stream serializationStream)
        {
            return GetBinaryFormatter().Deserialize(serializationStream);
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static object Deserialize(BinaryReader reader)
        {
            return GetBinaryFormatter().Deserialize(reader.BaseStream);
        }
        #endregion

        #region [Deserialize] NetData
        //------------------------------------------------------------------------------------------------------------------------------------------------------
        public static T Deserialize<T>(Stream serializationStream) where T : class
        {
            var obj = Deserialize(serializationStream);
            return obj as T;
        }
        #endregion






       

    }


    public static class JNewSerialization
    {
        #region [Deserialize] object (List, Dictionary, PrimitiveType, NetData)
        ////------------------------------------------------------------------------------------------------------------------------------------------------------
        //public static T Deserialize<T>(BinaryReader reader)
        //{
        //    object value = null;

        //    // todo: T ��ü�� List, Dictionary, PrimitiveType, JNetData_base�� ��� ����

        //    // NetData_base�� ��� �Ʒ� �Լ� ȣ��

        //    return value;
        //}
        #endregion
        
        #region [Deserialize] NetData
        ////------------------------------------------------------------------------------------------------------------------------------------------------------
        //public static T Deserialize<T>(BinaryReader reader) where T : JNetData_base, new ()
        //{
        //    var tp = typeof(T);
        //    var fields = tp.GetFields();
        //    var properties = tp.GetProperties();
        //    var target = new T();

            
        //    foreach (var fi in fields)
        //    {
        //        object value = null;

        //        // find read method
        //        MethodInfo readMethod;

        //        if((fi.FieldType == typeof(JNetData_base))) // todo: ��� ����
        //        {
        //            value = Deserialize<fi.FieldType>(reader);
        //        }
        //        else if ((fi.FieldType == typeof(IList))) 
        //        {
        //            value = Deserialize<fi.FieldType>(reader);
        //        }
        //        else if ((fi.FieldType == typeof(IDictionary)))
        //        {
        //            value = Deserialize<fi.FieldType>(reader);
        //        }
        //        else if (JReflection.s_read_methods.TryGetValue(fi.FieldType, out readMethod))
        //        {
        //            value = readMethod.Invoke(reader, null);                    
        //        }

        //        // set the value
        //        fi.SetValue(target, value);
        //    }

        //    return target;
        //}
        #endregion

        #region [Deserialize] RPC (object[])
        ////------------------------------------------------------------------------------------------------------------------------------------------------------
        //public static object[] Deserialize(BinaryReader reader, MethodInfo mi)
        //{
        //    var arguments = mi.GetGenericArguments();
        //    var target = new object[arguments.Length];
            
        //    foreach (var fi in arguments)
        //    {
        //        object value = null;

        //        // find read method
        //        MethodInfo readMethod;

        //        if ((fi.FieldType == typeof(JNetData_base))) // todo: ��� ����
        //        {
        //            value = Deserialize<fi.FieldType>(reader);
        //        }
        //        else if ((fi.FieldType == typeof(IList)))
        //        {
        //            value = Deserialize<fi.FieldType>(reader);
        //        }
        //        else if ((fi.FieldType == typeof(IDictionary)))
        //        {
        //            value = Deserialize<fi.FieldType>(reader);
        //        }
        //        else if (JReflection.s_read_methods.TryGetValue(fi.FieldType, out readMethod))
        //        {
        //            value = readMethod.Invoke(reader, null);
        //        }

        //        // set the value
        //        fi.SetValue(target, value);
        //    }

        //    return target;
        //}
        #endregion
    }


}
